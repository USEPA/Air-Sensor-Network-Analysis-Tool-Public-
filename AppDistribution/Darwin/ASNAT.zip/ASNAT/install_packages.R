
repository <- "http://cran.us.r-project.org"

if (!require(Rcpp)) install.packages("Rcpp", repos = repository)
if (!require(httr)) install.packages("httr", repos = repository)
if (!require(shiny)) install.packages("shiny", repos = repository)
if (!require(shinyBS)) install.packages("shinyBS", repos = repository)
if (!require(shinyjs)) install.packages("shinyjs", repos = repository)
if (!require(DT)) install.packages("DT", repos = repository)
if (!require(jsonlite)) install.packages("jsonlite", repos = repository)
if (!require(leaflet)) install.packages("leaflet", repos = repository)
if (!require(mapview)) install.packages("mapview", repos = repository)
if (!require(webshot)) install.packages("webshot", repos = repository)
if (!require(plotly)) install.packages("plotly", repos = repository)

cat("\n\nTesting that the Rtools C++ compiler works:\n")

Rcpp::sourceCpp(code = '
#include <Rcpp.h>
// [[Rcpp::export]]
bool test_cpp_works() {return true;}')

stopifnot(test_cpp_works())

cat("\n\nDone.\nYou can now run ASNAT\n")
