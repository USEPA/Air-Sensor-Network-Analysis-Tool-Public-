###############################################################################
# PURPOSE: app.R - ASNAT Controller/View.
#
# NOTES:  To run: ASNAT
#
#         Uses the Model-View/Controller (MVC) Design Pattern.
#         https://en.wikipedia.org/wiki/Model-view-controller
#         The Model is ASNAT_Model.R
#           (which has-a ASNAT_Dataset_Manager which has-a ASNAT_Dataset).
#         This file, app.R contains both
#           the Controller (ui function)
#             which defines the GUI that updates the Model state and
#           the View (server function) which displays the Model state/data.
#         Uses RShiny framework to implement the View and Controller.
#
#         The phantomjs, pandoc, ffmpeg and curl platform-specific
#         (Mac, Windows, Linux) executables will be deployed with the ASNAT
#         script.
#         These external programs are invoked to generate output image and
#         movie files of the map view. The curl program is used to retrieve
#         data from webservices.
#         Using the curl program is more robust than using httr::GET() -
#         which can cause the process to terminate upon failure.
#
# HISTORY: 2022-10-30 plessel.todd@epa.gov
# STATUS:  unreviewed tested
###############################################################################

.unused <- require(compiler, quietly = TRUE) && compiler::enableJIT(3)

###############################################################################
# Load required libraries:
###############################################################################

if ( Sys.getenv("R_CONFIG_ACTIVE") == "rsconnect" ) {
  library("shiny")
  library("shinyBS")
  library("shinyjs")
  library("DT")
  library("leaflet")
  library("mapview")
  library("webshot")
  library("plotly")
  library("zip")
} else {

  # URL to download any required R packages from:

  repository <- "http://cran.us.r-project.org"

  if (!require(shiny)) install.packages("shiny", repos = repository)
  if (!require(shinyBS)) install.packages("shinyBS", repos = repository)
  # https://github.com/daattali/advanced-shiny/blob/master/close-window/app.R
  if (!require(shinyjs)) install.packages("shinyjs", repos = repository)
  if (!require(DT)) install.packages("DT", repos = repository)
  if (!require(leaflet)) install.packages("leaflet", repos = repository)
  if (!require(mapview)) install.packages("mapview", repos = repository)
  if (!require(webshot)) install.packages("webshot", repos = repository)
  if (!require(plotly)) install.packages("plotly", repos = repository)
  if (!require(zip)) install.packages("zip", repos = repository)
  # webshot::install_phantomjs()
}


###############################################################################
# Load required source files:
###############################################################################

source("ASNAT_Utilities.R")
source("ASNAT_Dataset.R")
source("ASNAT_DatasetManager.R")
source("ASNAT_Model.R")

###############################################################################
# Initialize global constants:
###############################################################################

user_manual_url <-
  paste0(rsigserver_url, "asnat/download/ASNAT_User_Manual.pdf")

purple_air_attribution_url <- "https://www2.purpleair.com/pages/attribution"

all_purple_air_sites <- "0 All sensors in view"
all_dataset_x_neighbor_sites <- "0 All Sites"

# FIX: Sizes other than 992 x 744 make the saved image unmatched!
the_map_width = "992px"
the_map_height = "744px"

the_site_neighbor_map_width = "496px"
the_site_neighbor_map_height = "372px"

# Plot width/height are in inches:
the_pdf_width = 8L
the_pdf_height = 6L

# List of variables|units|description available from rsigserver webservice:

webservice_variable_metadata <- list(
  "AirNow.pm25|ug/m3|UTC hourly mean surface measured particulate matter (aerosols) 2.5 microns or smaller in diameter in micrograms per cubic meter.",
  "AirNow.pm10|ug/m3|UTC hourly mean surface measured particulate matter (aerosols) 10 microns or smaller in diameter in micrograms per cubic meter.",
  "AirNow.rh|%|UTC hourly mean surface measured relative humidity percentage.",
  "AirNow.temperature|C|UTC hourly mean surface measured air temperature (C)",
  "AirNow.pressure|C|UTC hourly mean surface measured atmospheric pressure (hPa)",
  "AirNow.ozone|ppb|UTC hourly mean surface measured ozone (ppb).",
  "AQS.pm25|ug/m3|UTC hourly mean surface measured particulate matter (aerosols) 2.5 microns or smaller in diameter in micrograms per cubic meter.",
  "AQS.pm10|ug/m3|UTC hourly mean surface measured particulate matter (aerosols) 10 microns or smaller in diameter in micrograms per cubic meter.",
  "AQS.rh|%|UTC hourly mean surface measured relative humidity in percent.",
  "AQS.temperature|C|UTC hourly mean surface measured air temperature (C)",
  "AQS.pressure|C|UTC hourly mean surface measured atmospheric pressure (hPa)",
  "AQS.ozone|ppb|UTC hourly mean surface measured ozone (ppb).",
  "METAR.relativeHumidity|%|Relative humidity (computed using Magnus approximation formula from temperature and dewPoint).",
  "METAR.temperature|C|Air temperature in degrees C.",
  "METAR.seaLevelPress|hPa|Atmospheric pressure equivalent at sea level in hPa.",
  "PurpleAir.pm25_corrected|ug/m3|Scaled humidity-corrected particulate matter not more than 2.5 microns in diameter.",
  "PurpleAir.humidity|%|Sensor measured relative humidity inside the sensor housing (on average 4% lower than ambient conditions).",
  "PurpleAir.temperature|C|Temperature inside of the sensor housing. On average, this is 4C higher than ambient conditions.",
  "=== Slow Variables Below ===|-|Retrieving the following variables will be much slower.",
  "PurpleAir.ozone1|ppb|Sensor measured ozone concentration.",
  "PurpleAir.pm1|ug/m3|Sensor measured particulate matter not more than 1 micron in diameter, average for channel A and B but excluding downgraded channels and using CF=1 variant for indoor, ATM variant for outdoor devices.",
  "PurpleAir.pm1_a|ug/m3|Sensor measured particulate matter not more than 1 micron in diameter, channel A CF=1 variant for indoor, ATM variant for outdoor devices.'",
  "PurpleAir.pm1_b|ug/m3|Sensor measured particulate matter not more than 1 micron in diameter, channel B CF=1 variant for indoor, ATM variant for outdoor devices.'",
  "PurpleAir.pm1_atm|ug/m3|Sensor measured particulate matter not more than 1 micron in diameter, ATM variant average for channel A and B but excluding downgraded channels.'",
  "PurpleAir.pm1_atm_a|ug/m3|Sensor measured particulate matter not more than 1 micron in diameter, channel A ATM variant.'",
  "PurpleAir.pm1_atm_b|ug/m3|Sensor measured particulate matter not more than 1 micron in diameter, channel B ATM variant.'",
  "PurpleAir.pm25|ug/m3|Sensor measured particulate matter not more than 2.5 microns in diameter, average for channel A and B but excluding downgraded channels and using CF=1 variant for indoor, ATM variant for outdoor devices.",
  "PurpleAir.pm25_a|ug/m3|Sensor measured particulate matter not more than 2.5 microns in diameter, channel A CF=1 variant for indoor, ATM variant for outdoor devices.'",
  "PurpleAir.pm25_b|ug/m3|Sensor measured particulate matter not more than 2.5 microns in diameter, channel B CF=1 variant for indoor, ATM variant for outdoor devices.'",
  "PurpleAir.pm25_atm|ug/m3|Sensor measured particulate matter not more than 2.5 microns in diameter, ATM variant average for channel A and B but excluding downgraded channels.'",
  "PurpleAir.pm25_atm_a|ug/m3|Sensor measured particulate matter not more than 2.5 microns in diameter, channel A ATM variant.'",
  "PurpleAir.pm25_atm_b|ug/m3|Sensor measured particulate matter not more than 2.5 microns in diameter, channel B ATM variant.'",
  "PurpleAir.pm25_cf_1|ug/m3|Sensor measured particulate matter not more than 2.5 microns in diameter, CF=1 variant average for channel A and B but excluding downgraded channels.'",
  "PurpleAir.pm25_cf_1_a|ug/m3|Sensor measured particulate matter not more than 2.5 microns in diameter, channel A CF=1 variant.'",
  "PurpleAir.pm25_cf_1_b|ug/m3|Sensor measured particulate matter not more than 2.5 microns in diameter, channel B CF=1 variant.'",
  "PurpleAir.pm25_10minute|ug/m3|Sensor measured particulate matter not more than 2.5 microns in diameter, 10 minute pseudo average using CF=1 data variant for indoor and ATM variant for outdoor, average for channel A and B but excluding downgraded channels.",
  "PurpleAir.pm25_10minute_a|ug/m3|Sensor measured particulate matter not more than 2.5 microns in diameter, 10 minute pseudo average using CF=1 data variant for indoor and ATM variant for outdoor, channel A running average.",
  "PurpleAir.pm25_10minute_b|ug/m3|Sensor measured particulate matter not more than 2.5 microns in diameter, 10 minute pseudo average using CF=1 data variant for indoor and ATM variant for outdoor, channel B running average.",
  "PurpleAir.pm25_60minute|ug/m3|Sensor measured particulate matter not more than 2.5 microns in diameter, 60 minute pseudo average using CF=1 data variant for indoor and ATM variant for outdoor, average for channel A and B but excluding downgraded channels.",
  "PurpleAir.pm25_60minute_a|ug/m3|Sensor measured particulate matter not more than 2.5 microns in diameter, 60 minute pseudo average using CF=1 data variant for indoor and ATM variant for outdoor, channel A running average.",
  "PurpleAir.pm25_60minute_b|ug/m3|Sensor measured particulate matter not more than 2.5 microns in diameter, 60 minute pseudo average using CF=1 data variant for indoor and ATM variant for outdoor, channel B running average.",
  "PurpleAir.pm10|ug/m3|Sensor measured particulate matter not more than 10 microns in diameter, average for channel A and B but excluding downgraded channels and using CF=1 variant for indoor, ATM variant for outdoor devices.",
  "PurpleAir.pm10_a|ug/m3|Sensor measured particulate matter not more than 10 microns in diameter, channel A CF=1 variant for indoor, ATM variant for outdoor devices.",
  "PurpleAir.pm10_b|ug/m3|Sensor measured particulate matter not more than 10 microns in diameter, channel B CF=1 variant for indoor, ATM variant for outdoor devices.",
  "PurpleAir.pm10_atm|ug/m3|Sensor measured particulate matter not more than 10 microns in diameter, ATM variant average for channel A and B but excluding downgraded channels.",
  "PurpleAir.pm10_atm_a|ug/m3|Sensor measured particulate matter not more than 10 microns in diameter, channel A ATM variant.",
  "PurpleAir.pm10_atm_b|ug/m3|Sensor measured particulate matter not more than 10 microns in diameter, channel B ATM variant.",
  "PurpleAir.pm10_cf_1|ug/m3|Sensor measured particulate matter not more than 10 microns in diameter, CF=1 variant average for channel A and B but excluding downgraded channels.'",
  "PurpleAir.pm10_cf_1_a|ug/m3|Sensor measured particulate matter not more than 10 microns in diameter, channel A CF=1 variant.'",
  "PurpleAir.pm10_cf_1_b|ug/m3|Sensor measured particulate matter not more than 10 microns in diameter, channel B CF=1 variant.'",
  "PurpleAir.0_3_um_count|particles/100ml|Count concentration of all particles greater than 0.3 microns in diameter, average particle count for channel A and B but excluding downgraded channels.",
  "PurpleAir.0_3_um_count_a|particles/100ml|Count concentration of all particles greater than 0.3 microns in diameter, channel A.",
  "PurpleAir.0_3_um_count_b|particles/100ml|Count concentration of all particles greater than 0.3 microns in diameter, channel B.",
  "PurpleAir.0_5_um_count|particles/100ml|Count concentration of all particles greater than 0.5 microns in diameter, average particle count for channel A and B but excluding downgraded channels.",
  "PurpleAir.0_5_um_count_a|particles/100ml|Count concentration of all particles greater than 0.5 microns in diameter, channel A.",
  "PurpleAir.0_5_um_count_b|particles/100ml|Count concentration of all particles greater than 0.5 microns in diameter, channel B.",
  "PurpleAir.1_um_count|particles/100ml|Count concentration of all particles greater than 1 micron in diameter, average particle count for channel A and B but excluding downgraded channels.",
  "PurpleAir.1_um_count_a|particles/100ml|Count concentration of all particles greater than 1 micron in diameter, channel A.",
  "PurpleAir.1_um_count_b|particles/100ml|Count concentration of all particles greater than 1 micron in diameter, channel B.",
  "PurpleAir.2_5_um_count|particles/100ml|Count concentration of all particles greater than 2.5 microns in diameter, average particle count for channel A and B but excluding downgraded channels.",
  "PurpleAir.2_5_um_count_a|particles/100ml|Count concentration of all particles greater than 2.5 microns in diameter, channel A.",
  "PurpleAir.2_5_um_count_b|particles/100ml|Count concentration of all particles greater than 2.5 microns in diameter, channel B.",
  "PurpleAir.5_um_count|particles/100ml|Count concentration of all particles greater than 5 microns in diameter, average particle count for channel A and B but excluding downgraded channels.",
  "PurpleAir.5_um_count_a|particles/100ml|Count concentration of all particles greater than 5 microns in diameter, channel A.",
  "PurpleAir.5_um_count_b|particles/100ml|Count concentration of all particles greater than 5 microns in diameter, channel B.",
  "PurpleAir.10_um_count|particles/100ml|Count concentration of all particles greater than 10 microns in diameter, average particle count for channel A and B but excluding downgraded channels.",
  "PurpleAir.10_um_count_a|particles/100ml|Count concentration of all particles greater than 10 microns in diameter, channel A.",
  "PurpleAir.10_um_count_b|particles/100ml|Count concentration of all particles greater than 10 microns in diameter, channel B.",
  "PurpleAir.pressure|hPa|Sensor measured atmospheric pressure.",
  "PurpleAir.voc|IAQ|Sensor measured volatile organic compounds in Bosch static IAQ units as per BME680 spec sheet (EXPERIMENTAL).",
  "" # End of list.
)

# Construct lists used for menus and tooltips:

webservice_variables <- list()
webservice_units <- list()
webservice_descriptions <- list()

initialize_variable_lists <- function() {
  count <- 0L

  for (entry in webservice_variable_metadata) {

    if (entry != "") {
      parts <- unlist(strsplit(entry, "|", fixed = TRUE))
      stopifnot(length(parts) == 3L)
      count <- count + 1L
      webservice_variables[count] <<- parts[[1L]]
      webservice_units[count] <<- parts[[2L]]
      webservice_descriptions[count] <<- parts[[3L]]
    }
  }
}

initialize_variable_lists()



# Declare default MVC Model Singleton.
#
# Use case 1 - running the app locally, either by using ASNAT shell program or
# in RStudio on the user's laptop:
# 1. This 'default_model' object will be initialized from reading the user's
#    .asnat file (if it exists).
#    For example, the map would be zoomed to the same viewing area as last time
#    the user ran this app (e.g., Boston) rather than the default viewing area
#    (NYC).
# 2. Inside server() the 'model' object will refer to (alias) 'default_model'.
#
# Use case 2 - running remote-hosted, e.g., rstudio-connect as client-server:
# 1. There is no .asnat file so this 'default_model' object will be initialized
#    to 'standard' state (NYC, etc.).
# 2. Inside server() the 'model' object will be independent of 'default_model'
#    so that each client user will have their own 'session' and their own
#    'model'. Additionally, to avoid having multiple concurrent users overwrite
#    each others temporary files, the unique session$token will be used in the
#    created temporary data directory used to hold data streamed from
#    webservices and for temporary computed results such as tables.

default_model <- ASNAT_Model()



################ Globals and functions for map legend colormaps ###############


# Helper function to make a color array used for the map legend.
# my_colormap <- make_colormap(c(68, 72), c(13, 21), c(84, 104))

make_colormap <- function(reds, greens, blues) {
  stopifnot(length(reds) > 0L)
  stopifnot(length(greens) == length(reds))
  stopifnot(length(blues) == length(reds))
  result <- rep(0L, length(reds))

  for (index in seq_along(reds)) {
    result[index] <-
      rgb(reds[index], greens[index], blues[index], maxColorValue = 255L)
  }

  return(result)
}



# Legend colormaps are ordered from lowest value to highest value.
# They have only about a half dozen discernable hues.
# Workaround R/Leaflet BUG: "green" was replaced with "#00FF00" otherwise
# "green" appears as "green4" (dark green) in the legend.

the_default_colormap <-
c("black", "blue", "cyan", "#00FF00", "yellow", "red", "magenta")

# https://aqs.epa.foc/aqsweb/documents/codetables/aqi_breakpoints.html

the_aqi_colormap <- c("#00FF00", "yellow", "orange", "red", "purple", "maroon")
the_aqi_names <- c("Good", "Moderate", "Unhealthy for some", "Unhealthy",
                   "Very Unhealthy", "Hazardous")

# pm25(ug/m3), ozone(ppm):

the_pm25_daily_aqi_breakpoints <- c(12.0, 35.4, 55.4, 150.4, 250.4, 1e6)
the_pm10_daily_aqi_breakpoints <- c(54.0, 154.0, 254.0, 354.0, 424.0, 1e6)
the_ozone_8_hour_aqi_breakpoints <- c(0.054, 0.07, 0.085, 0.105, 0.2, 1e3)
the_ozone_1_hour_aqi_breakpoints <- c(0.124, 0.163, 0.164, 0.024, 0.404, 1e3)
PPM_TO_PPB <- 1000.0
the_ozone_8_hour_aqi_breakpoints <- the_ozone_8_hour_aqi_breakpoints * PPM_TO_PPB
the_ozone_1_hour_aqi_breakpoints <- the_ozone_1_hour_aqi_breakpoints * PPM_TO_PPB

# The viridis colormap is supposedly discernable by color-impaired viewers.
# The viridis rgb values are from RSIG3D file RGBColormap.cpp.

the_viridis_reds <-
##c(68,  72,  72,  69,  63,  57,  50,  45,  39,  35,  31,  32,  41,  60,  86, 116, 148, 184, 220, 253)
  c(0,  72,  50,  31,  86, 220)
the_viridis_greens <-
##c(13,  21,  38,  55,  71,  85, 100, 112, 125, 138, 150, 163, 175, 188, 198, 208, 216, 222, 227, 231)
  c(0,  38, 100, 150, 198, 227)
the_viridis_blues <-
##c(84, 104, 119, 129, 136, 140, 142, 142, 142, 141, 139, 134, 127, 117, 103,  85,  64,  41,  23,  37)
  c(0, 119, 142, 139, 103,  23)

the_viridis_colormap <-
  make_colormap(the_viridis_reds, the_viridis_greens, the_viridis_blues)

# https://www.codeofcolors.com/web-safe-colors.html
# retigo/stable/images/conc_symbols_colorsafe_inverted/conc_*.png

the_colorsafe_reds <-
##c(127, 255, 255, 249, 240, 230, 220, 210, 164, 142, 117, 107,  95,  81,  64,  39,  17 )
  c(230, 255, 240, 210, 142, 107,  64 )

the_colorsafe_greens <-
##c(127, 254, 252, 252, 241, 231, 220, 210, 150, 124,  99,  86,  71,  57,  41,  22,   9 )
  c(230, 252, 241, 210, 124,  86,  41 )

the_colorsafe_blues <-
##c(127, 203, 152, 101, 104, 108, 110, 113, 184, 192, 199, 201, 202, 204, 206, 207, 130 )
  c(230, 152, 104, 113, 192, 201, 206 )


the_ramp_down <- seq(253L, 0L, by = -40L)
#  { 255, 255, 255, 255, 255, 255, 255, 255, 255, 244, 232, 221, 209, 197, 186, 174, 162, 151, 139, 128  }  // blue
the_ramp_half_down <- c(255L, 255L, 255L, 232L, 186L, 139L, 128L)

the_gray_colormap <- make_colormap(the_ramp_down, the_ramp_down, the_ramp_down)
the_blue_colormap <-
  make_colormap(the_ramp_down, the_ramp_down, the_ramp_half_down)
the_colorsafe_colormap <-
  make_colormap(the_colorsafe_reds, the_colorsafe_greens, the_colorsafe_blues)



################# Globals and functions for colored map glyphs ################


# Constants:

glyph_size <- 40L
glyph_scale <- 2L
glyph_border_color <- "black"


# glyph pch codes: https://r-lang.com/pch-in-r/

the_glyphs <- list(filled_triangle_pointing_down = 25L,
                   filled_diamond = 23L,
                   filled_square = 22L,
                   filled_triangle_pointing_up = 24L,
                   filled_circle = 21L)


# Define function that returns the integer pch (point character) map glyph
# for a given coverage (source.variable).
#
# Note the choice of shape is not arbitrary but rather based on stability.
# A square is a stable shape so it is used to depict the most stable data: AQS.
# A diamond is unstable but when it falls over it becomes a stable square
# which is what becomes of AirNow data - it becomes AQS data (after extensive
# QA revisions).
# A triangle pointing up is stable and is like an airplane so it depicts METAR
# (mostly airport) data.
# A circle is unstable as is questionable PurpleAir measurements.
# A downward-pointing triangle is unstable but might become stable so it
# depicts other data read from files.

map_glyph <- function(coverage) {
  parts <- unlist(strsplit(coverage, ".", fixed = TRUE))
  data_source <- parts[[1L]]
  result <- the_glyphs$filled_triangle_pointing_down

  if (data_source == "AirNow") {
    result <- the_glyphs$filled_diamond
  } else if (data_source == "AQS") {
    result <- the_glyphs$filled_square
  } else if (data_source == "METAR") {
    result <- the_glyphs$filled_triangle_pointing_up
  } else if (data_source == "PurpleAir") {
    result <- the_glyphs$filled_circle
  }

  return(result)
}



# Define a function that generates a glyph png file name:

glyph_file_name <- function(glyph, color) {
  directory <- "data/glyphs"

  if (!dir.exists(directory)) {
    dir.create(directory, recursive = TRUE)
  }

  result <- paste0(directory, "/", glyph, "_", color, ".png")
  return(result)
}



# Function that generates glyph png files used to display point data on the map:
# https://www.appsloveworld.com/r/100/333/r-shiny-leaflet-add-crosses-for-points

create_glyph_files <- function(glyphs, colormap) {
  result <- c()
  index <- 1L

  for (glyph in glyphs) {

    for (color in colormap) {
      file_name <- glyph_file_name(glyph, color)

      if (!file.exists(file_name)) {
        png(file_name, width = glyph_size, height = glyph_size,
            bg = "transparent")
        par(mar = c(0L, 0L, 0L, 0L))
        plot.new()

        # Must use bg = color so down-pointing triangle is filled:

        points(0.5, 0.5, pch = glyph, col = glyph_border_color,
               cex = glyph_scale, bg = color)
        dev.off() # Close the plot and (magically) write png file.
      }

      result[index] <- file_name
      index <- index + 1L
    }
  }

  return(result)
}


the_default_glyph_files <- create_glyph_files(the_glyphs, the_default_colormap)
the_aqi_glyph_files <- create_glyph_files(the_glyphs, the_aqi_colormap)
the_viridis_glyph_files <- create_glyph_files(the_glyphs, the_viridis_colormap)
the_gray_glyph_files <- create_glyph_files(the_glyphs, the_gray_colormap)
the_blue_glyph_files <- create_glyph_files(the_glyphs, the_blue_colormap)
the_colorsafe_glyph_files <-
  create_glyph_files(the_glyphs, the_colorsafe_colormap)



# Define options for all tooltips:
# https://stackoverflow.com/questions/47477237/delaying-and-expiring-a-shinybsbstooltip#47478586

tooltip_options <- list("delay': 1000, 'hack" = "hack")



###############################################################################
# Declare ui object that defines the GUI Controller.
# Note this is a single function call to fluidPage() with a very long
# comma-delimited sequence of expressions.
###############################################################################

ui <- fluidPage(

  # When run outside RStudio, close the browser tab upon exit.
  # https://github.com/daattali/advanced-shiny/blob/master/close-window/app.R

  shinyjs::useShinyjs(),
  shinyjs::extendShinyjs(text = "shinyjs.closeWindow = function() {window.close();}",
                         functions = c("closeWindow")),


  # 1. The tags magic is needed to make scrolling work with tags$div() used for
  #    the list of variables.
  # 2. Make message area scrolling.
  # 3. Make popup messages appear at the top of the page.
  #    https://github.com/rstudio/shiny/issues/2988
  # 4. Try to reduce the amount of whitespace of map timestamp and legends.
  #    https://github.com/rstudio/leaflet/issues/488

  tags$head(
    tags$style(type = "text/css",
               ".scrolling .shiny-bound-input{overflow-y: scroll;}"),
    tags$style(type = "text/css",
               "#message_area {width: 100%; height: 60px; overflow: scroll;}"),
    tags$style(type = "text/css",
               "#shiny-notification-panel {
                 top: 0; bottom: unset; left: 0; right: 0;
                 margin-left: auto; margin-right: auto;
                 width: 100%;
                 max-width: 450px;
               }")
    #tags$style(type="text/css",
    #          ".leaflet .legend {line-height: 10px; font-size: 10px;}",
    #          ".leaflet .legend i{height: 10px; width: 10px;}")
  ),

  titlePanel("ASNAT"),

  h5("asnat@epa.gov"),
  tags$a(href = user_manual_url, user_manual_url),
  verbatimTextOutput("message_area", placeholder = TRUE),

  fluidRow(
    column(4L,
      actionButton("reset_map", label = "Reset map"),

      shinyBS::bsTooltip("reset_map",
                         "Reset map to default state.",
                         options = tooltip_options),

      h5("1. Pan/zoom map to region of interest."),
      h5("2. Start Date,Days to retrieve,Aggregate:"),

      fluidRow(
        column(5L,
               dateInput("start_date", label = "Start Date:",
                         #width = "100px",
                         value = start_date(default_model),
                         min = "1970-01-01", max = Sys.Date() + 1L),

        shinyBS::bsTooltip("start_date",
                           "Starting date of data to load.",
                           options = tooltip_options)),
        column(3L,
               numericInput("days", label = "Days:",
                            #width = "100px",
                            value = days(default_model),
                            min = 1L,
                            max = 366L,
                            step = 1L),

               shinyBS::bsTooltip("days",
                                 "Number of days of data to load.",
                                 options = tooltip_options)),

        column(4L,
               selectInput("timestep_size",
                           label = "Timestep:  ",
                           #width = "120px",
                           choices = list("hours", "days"),
                           selected = timestep_size(default_model)),

               shinyBS::bsTooltip("timestep_size",
                                  "Timestep size and data aggregation.",
                                  placement = "top",
                                  options = tooltip_options))
      ),

      actionButton("delete_data", label = "Delete Loaded Data"),

      shinyBS::bsTooltip("delete_data",
                         paste0("Delete any data in memory and ",
                                "previously retrieved disk cache."),
                         options = tooltip_options),

      # The tags$div() is needed to make selectInput() scolling.

      tags$div(id = "scrolling1", class = "scrolling",
               selectInput("coverage_menu",
                           label = "Load Web (control/command-click two):",
                           multiple = TRUE, selectize = FALSE,
                           choices = webservice_variables,
                           size = 18L)),

      shinyBS::bsTooltip("coverage_menu",
                         paste0("Select one or two variables to retrieve ",
                                "from a webservice."),
                         options = tooltip_options),

      tags$a(href = purple_air_attribution_url, purple_air_attribution_url),

      textInput("purple_air_key", "PurpleAir Key:",
                value = purple_air_key(default_model)),

      shinyBS::bsTooltip("purple_air_key",
                         "Request a read key from contact@purpleair.com.",
                         placement = "top",
                         options = tooltip_options),

      tags$div(id = "scrolling2", class = "scrolling",
               selectizeInput("purple_air_sites_menu",
                              label = "Purple Air Sites:",
                              options = list(maxItems = 1L),
                              choices = NULL)),

      shinyBS::bsTooltip("purple_air_sites_menu",
                         paste0("Optionally select a single PurpleAir sensor ",
                                "within the viewing area to retrieve ",
                                "(or 0 for all sensors)."),
                         placement = "top",
                         options = tooltip_options),

      actionButton("retrieve_data", label = "Retrieve Data"),

      shinyBS::bsTooltip("retrieve_data",
                         "Retrieve data from a webservice.",
                         options = tooltip_options),

      h1(),

      fileInput("load_data_from_standard_file",
                label = "Load data from a standard-format file:",
                multiple = FALSE,
                accept = list(".csv", ".tsv", ".txt", "text/plain")),

      shinyBS::bsTooltip("load_data_from_standard_file",
                         "Load data from a standard-format file.",
                         options = tooltip_options),

      h1(),

      actionButton("show_import_fileset",
                   label = "Load data from sensor instrument files"),

      shinyBS::bsTooltip("show_import_fileset",
                         "Show dialog for loading sensor data from files.",
                         options = tooltip_options),

      h1(),

      selectInput("dataset_x_menu",
                  label = "Select Comparison Dataset X:",
                  choices = list()),

      selectInput("dataset_x_variable_menu",
                  label = "Select Variable Of Dataset X:",
                  choices = list()),

      selectInput("dataset_y_menu",
                  label = "Select Comparison Dataset Y:",
                  choices = list()),

      selectInput("dataset_y_variable_menu",
                  label = "Select Variable Of Dataset Y:",
                  choices = list()),

      # The tag magic is needed to force label on the same line as widget:

      tags$div(style = "display: inline-block;vertical-align:top;",
               h5("Neighbor distance(m):")),
      tags$div(style = "display: inline-block;vertical-align:top; width: 45%;",
               numericInput("maximum_neighbor_distance",
               #label = "Max neighbor distance(m):",
               label = NULL,
               width = "80px",
               value = maximum_neighbor_distance(default_model),
               min = 0.0, max = 10000.0, step = 100.0)),

      shinyBS::bsTooltip("maximum_neighbor_distance",
                         paste0("Maximum distance in meters between ",
                                "time-matched X and Y neighbor points."),
                         options = tooltip_options),

      if (!ASNAT_is_remote_hosted) textInput("output_directory",
                                             label = "Save to Directory:",
                                             value =
                                               output_directory(default_model)),

      if (!ASNAT_is_remote_hosted) shinyBS::bsTooltip("output_directory",
                                     paste0("Select directory/folder to use ",
                                            "when saving loaded data files."),
                                                    options = tooltip_options),

      # The tag magic is needed to force label on the same line as widget:

      tags$div(style = "display: inline-block;vertical-align:top;",
               h5("Output File Format:")),
      tags$div(style = "display: inline-block;vertical-align:top; width: 80px;",
               selectInput("output_format_menu",
                           #label = "Output File Format:",
                           label = NULL,
                           choices = list("csv", "tsv", "json"),
                  selected = output_format(default_model))),
      br(),

      shinyBS::bsTooltip("output_format_menu",
                         "Select format of files when saving.",
                         placement = "top",
                         options = tooltip_options),

      if (!ASNAT_is_remote_hosted) actionButton("save_data", label = "Save Data") else
      downloadButton(outputId = "download_data", label = "Save Data"),

      shinyBS::bsTooltip("save_data",
                         "Save all loaded datasets and tables.",
                         options = tooltip_options),

      shinyBS::bsTooltip("download_data",
                         "Save all loaded datasets and tables as a zip file.",
                         options = tooltip_options),

      actionButton("quit", label = "Quit"),

      shinyBS::bsTooltip("quit",
                         "Save state and quit application.",
                         options = tooltip_options)

    ),

    # The following GUI elements appear as tabs on the right side of the page:

    column(8L,
      tabsetPanel(id = "tabs",

        tabPanel("Map", value = "map",

                 # The map width/height is set to match the default dimensions
                 # (somehow/automatically) set when saving images.
                 # This avoids surprises by ensuring that the saved map image
                 # appears the same as when viewed in this program.

                 leafletOutput("map",
                               width = the_map_width,
                               height = the_map_height),

                 selectInput("legend_colormap_menu",
                             label = "Legend Colormap",
                             choices = list("default", "AQI", "gray", "blue",
                                            "colorsafe", "viridis"),
                             selected = legend_colormap(default_model)),

                 shinyBS::bsTooltip("legend_colormap_menu",
                                    paste0("Choose a legend colormap for data ",
                                           "displayed on the map. ",
                                           "(AQI note: PM hourly uses daily ",
                                           "breakpoints, ",
                                           "PM1 uses PM2.5 breakpoints and ",
                                           "ozone daily uses 8-hour ",
                                           "breakpoints)."),
                                    options = tooltip_options),

                 checkboxInput("use_fancy_labels",
                                label = "Use fancy names/units",
                                value = use_fancy_labels(default_model)),

                 shinyBS::bsTooltip("use_fancy_labels",
                                    paste0("Use sub/superscripts and symbols ",
                                    "for some variable names and units."),
                                    options = tooltip_options),

                 sliderInput("timestep_slider", label = "Timestep:",
                             value = timestep(default_model),
                             min = 0, max = timesteps(default_model) - 1L,
                             step = 1L),

                 shinyBS::bsTooltip("timestep_slider",
                                    "Set timestep to display.",
                                    options = tooltip_options),

                 actionButton("zoom_to_data", label = "Zoom To Data"),

                 shinyBS::bsTooltip("zoom_to_data",
                                    "Zoom map to location of loaded data.",
                                    options = tooltip_options),

                 if (!ASNAT_is_remote_hosted) actionButton("save_map_image", label = "Save Map Image") else
                 downloadButton(outputId = "download_map_image", label = "Save Map Image"),

                 shinyBS::bsTooltip("save_map_image",
                                    "Save current map image as a png file.",
                                    options = tooltip_options),

                 shinyBS::bsTooltip("download_map_image",
                                    "Save current map image as a png file.",
                                    options = tooltip_options),

                 if (!ASNAT_is_remote_hosted) actionButton("save_map_movie", label = "Save Map Movie") else
                 downloadButton(outputId = "download_map_movie", label = "Save Map Movie"),

                 shinyBS::bsTooltip("save_map_movie",
                                    "Save all map images as a movie file.",
                                    options = tooltip_options),

                 shinyBS::bsTooltip("download_map_movie",
                                    "Save all map images as a movie file.",
                                    options = tooltip_options)
        ),

        tabPanel("Flagging", value = "flagging",

                 selectInput("flag_dataset_menu", label = "Dataset to Flag:  ",
                             choices = list("Dataset X", "Dataset Y"),
                             selected = "Dataset X"),

                 shinyBS::bsTooltip("flag_dataset_menu",
                                    "Dataset to flag/reflag.",
                                    options = tooltip_options),

                 # Must use DT::dataTableOutput() to show data frames too large
                 # to fit on a single page.
                 # Also, implements multi-row selection for manual flagging.

                 DT::dataTableOutput("dataset_content_to_flag"),

                 shinyBS::bsTooltip("dataset_content_to_flag",
                                    "Optionally select data rows to flag 99",
                                    placement = "top",
                                    options = tooltip_options),

                 br(),

                 actionButton("exclude_99_flagged",
                              label = "Exclude 99 from flagged column"),

                 shinyBS::bsTooltip("exclude_99_flagged",
                                    "Exclude 99 from selected rows flagged column.",
                                    options = tooltip_options),

                 actionButton("include_99_flagged",
                              label = "Include 99 in flagged column"),

                 shinyBS::bsTooltip("include_99_flagged",
                                    "Include 99 in selected rows flagged column.",
                                    options = tooltip_options),

                 br(),

                 fileInput("load_flag_conditions",
                           label = "Load flag conditions from a file:",
                           multiple = FALSE,
                           accept = list(".txt", "text/plain")),

                 shinyBS::bsTooltip("load_flag_conditions",
                                    "Load flag conditions from a file.",
                                    options = tooltip_options),

                 textAreaInput("flag_conditions", "Flag Conditions:",
                               width = "800px", rows = 10L),

                 shinyBS::bsTooltip("flag_conditions",
                                    paste0("Enter flag conditions here - ",
                                           "one per line.\n",
                                           "Flag conditions are boolean ",
                                           "expressions comparing the ",
                                           "dataset's column values to ",
                                           "numbers using the column name ",
                                           "and operators 'or', 'and', ",
                                           "<, <=, >, >=, =\n",
                                           "E.g., pm25 < 0"),
                                    options = tooltip_options),

                 br(),

                 actionButton("apply_flagging", label = "Apply Flagging"),

                 shinyBS::bsTooltip("apply_flagging",
                                    paste0("Apply all of the above flagging ",
                                    "to Dataset Y ",
                                    "(or Dataset X if Dataset Y is none)."),
                                    options = tooltip_options),

                 h1(),

                 if (!ASNAT_is_remote_hosted) actionButton("save_flag_conditions", label = "Save Flag Conditions") else
                 downloadButton(outputId = "download_flag_conditions",
                                label = "Save Flag Conditions"),

                 shinyBS::bsTooltip("save_flag_conditions",
                                    paste0("Save flag conditions to file ",
                                           "<save-directory>/flags.txt."),
                                    options = tooltip_options),

                 hr(),
                 h5("Dataset Y Neighbor Flagging:"),

                 fluidRow(column(5L,
                                 checkboxInput("apply_difference",
                                               label = "Apply flag 80 if difference > ",
                                               value = apply_maximum_neighbor_value_difference(default_model))),
                          column(4L,
                                 numericInput("maximum_neighbor_value_difference",
                                              label = NULL,
                                              width = "80px",
                                              value = maximum_neighbor_value_difference(default_model),
                                              min = 0.0, max = 100.0, step = 1.0))),

                 shinyBS::bsTooltip("maximum_neighbor_value_difference",
                                    paste0("Mark Dataset Y flagged column with",
                                           " 80 if the absolute difference",
                                           " of the time-matched comparison",
                                           " variable with Dataset X is",
                                           " greater than value."),
                                    placement = "top",
                                    options = tooltip_options),

                 fluidRow(column(5L,
                                 checkboxInput("apply_percent_difference",
                                               label = "Apply flag 81 if percent difference > ",
                                               value = apply_maximum_neighbor_value_percent_difference(default_model))),
                          column(4L,
                                 numericInput("maximum_neighbor_value_percent_difference",
                                              label = NULL,
                                              width = "80px",
                                              value = maximum_neighbor_value_percent_difference(default_model),
                                              min = 0.0, max = 100.0, step = 1.0))),

                 shinyBS::bsTooltip("maximum_neighbor_value_percent_difference",
                                    paste0("Mark Dataset Y flagged column with",
                                           " 81 if the percent difference",
                                           " of the time-matched comparison",
                                           " variable with Dataset X is",
                                           " greater than value."),
                                    placement = "top",
                                    options = tooltip_options),

                 fluidRow(column(5L,
                                 checkboxInput("apply_r_squared",
                                               label = "Apply flag 82 if R-squared < ",
                                               value = apply_minimum_neighbor_value_r_squared(default_model))),
                          column(4L,
                                 numericInput("minimum_neighbor_value_r_squared",
                                              label = NULL,
                                              width = "80px",
                                              value = minimum_neighbor_value_r_squared(default_model),
                                              min = 0.0, max = 1.0, step = 0.1))),

                 shinyBS::bsTooltip("minimum_neighbor_value_r_squared",
                                    paste0("Mark Dataset Y flagged column with",
                                           " 82 if the R-squared",
                                           " (per-site over all timesteps,",
                                           " excluding already flagged values)",
                                           " of the comparison",
                                           " variable with Dataset X is",
                                           " less than value."),
                                    placement = "top",
                                    options = tooltip_options)
        ),

        tabPanel("Tables", value = "tables",

                 actionButton("summarize",
                              label = "Summarize and Compare X and Y"),

                 shinyBS::bsTooltip("summarize",
                                    paste0("Summarize and compare selected ",
                                           "X and Y datasets."),
                                    options = tooltip_options),

                 tableOutput("table1"),
                 tableOutput("table2"),
                 tableOutput("table3"),
                 tableOutput("table4")
        ),

        tabPanel("Plots", value = "plots",

                 h5("Neighbors Map - Shows Neighbors of (Single) Selected Dataset X Site"),

                 leafletOutput("site_neighbor_map",
                               width = the_site_neighbor_map_width,
                               height = the_site_neighbor_map_height),

                 checkboxInput("show_site_labels",
                                label = "Show site labels",
                                value = show_site_labels(default_model)),

                 shinyBS::bsTooltip("show_site_labels",
                                    paste0("Show site id labels."),
                                    options = tooltip_options),

                 tags$div(id = "scrolling3", class = "scrolling",
                          selectizeInput("neighbors_menu",
                                         label = "Select Dataset X Site With Neighbors:",
                                         options = list(maxItems = 1L),
                                         choices = NULL)),

                 shinyBS::bsTooltip("neighbors_menu",
                                    paste0("Select a single Dataset X site ",
                                           "(that has Dataset Y neighbors) ",
                                           "(or 0 for all)"),
                                    placement = "top",
                                    options = tooltip_options),

                 checkboxInput("use_interactive_plots",
                                label = "Use interactive plots",
                                value = use_interactive_plots(default_model)),

                 shinyBS::bsTooltip("use_interactive_plots",
                                    "Use interactive/color plots.",
                                    options = tooltip_options),

                 actionButton("make_plots",
                              label = "Make Plots of Datasets X, Y"),

                 shinyBS::bsTooltip("make_plots",
                                    "Make plots of selected X and Y datasets.",
                                    options = tooltip_options),

                 if (!ASNAT_is_remote_hosted) actionButton("save_plots", label = "Save Plots") else
                 downloadButton(outputId = "download_plots",
                                label = "Save Plots"),

                 shinyBS::bsTooltip("save_plots",
                                    "Save pdf files of plots and map.",
                                    options = tooltip_options),

                 shinyBS::bsTooltip("download_plots",
                                    "Save pdf files of plots and map.",
                                    options = tooltip_options),

                 br(),
                 br(),
                 plotOutput("boxplot_x"),
                 plotlyOutput("interactive_boxplot_x"),
                 br(),
                 br(),
                 br(),
                 plotOutput("timeseriesplot_x"),
                 plotlyOutput("interactive_timeseriesplot_x"),
                 br(),
                 hr(),
                 br(),
                 plotOutput("boxplot_y"),
                 plotlyOutput("interactive_boxplot_y"),
                 br(),
                 br(),
                 br(),
                 plotOutput("timeseriesplot_y"),
                 plotlyOutput("interactive_timeseriesplot_y"),
                 br(),
                 hr(),
                 br(),
                 plotOutput("scatterplot_xy"),
                 plotlyOutput("interactive_scatterplot_xy"),
                 br(),
                 hr(),
                 br(),
                 plotOutput("scatterplot_xy_unflagged"),
                 plotlyOutput("interactive_scatterplot_xy_unflagged"),
                 br(),
                 hr(),
                 br()
        )
      )
    )
  )
)



###############################################################################
# Define function, server, that handles GUI events (View).
#
# Note this is a definition of a function whose very large body contains
# delarations of some objects, function calls and many inner function
# definitions - either helper functions of the form
#   function_name <- function(args) {body}
# or GUI callback registration calls of the form
#   observeEvent(input$widget, {body})
# The input object contains the widgets (buttons, menus, slider, etc.),
# the output object contains the rendered objects (e.g., map, tables, plots)
# the session object is used to distinguish concurrent server-side processes
# from different users when running in a hosted environment (rstudio-connect)
# and also to update client-side widgets.
###############################################################################

server <- function(input, output, session) {
  ASNAT_dprint("server called.\n")

  #https://stackoverflow.com/questions/18037737/how-to-change-maximum-upload-size-exceeded-restriction-in-shiny-and-save-user#18037912
  options(shiny.maxRequestSize = 500L * 1024L * 1024L)

  rsigserver_host <- unlist(strsplit(rsigserver_url, "/"))[[3L]]
  output$message_area <-
    renderPrint({cat("Welcome. ",
                     "R-version: ", paste0(R.version["major"], ".",
                                           R.version["minor"]),
                     " platform: ", ASNAT_platform(),
                     " host: ", Sys.info()[[4L]],
                     " wd: ", getwd(),
                     " pid: ", Sys.getpid(),
                     " session$token: ", session$token,
                     " rsigserver-host: ", rsigserver_host,
                     "\n", sep = "")})

  # Declare client-specific (non-shared) model object.
  # If running locally then just reference the global default_model
  # else running remote-hosted (e.g., rstudio-connect) so create a model object
  # that is session-specific - i.e., not shared but rather unique to each client
  # and also create and use a unique data sub-directory for temporary files so
  # that if clients are connected to the same server process (host+pid) and
  # have the same current directory then they will write to different
  # sub-directories to avoid interfering with each other:

  model <- NULL

  if (!ASNAT_is_remote_hosted) {
    model <- default_model

    # Check if there is a newer version of this program available for download:

    if (is_newer_version_available(model)) {
      url <- download_url(model)
      message <- sprintf("A newer version of ASNAT is available:\n%s\n", url)
      showNotification(message, duration = NULL, closeButton = TRUE,
                       type = "message")
    }
  } else {
    model <- ASNAT_Model(session$token)
  }

  # Define and install function to be called upon app exit:

  on_quit <- function() {
    ASNAT_dprint("on_quit() called before exiting app.\n")

    if (!ASNAT_is_remote_hosted) {
      ASNAT_dprint("Saving model state.\n")
      model <<- save_state(model)
    }
  }

  if (!ASNAT_is_remote_hosted) {

    # https://github.com/daattali/advanced-shiny/blob/master/auto-kill-app/app.R

    session$onSessionEnded(stopApp)
    onStop(on_quit)
  }

  if (!rsigserver_is_reachable) {
    message <- paste0("Warning: ", rsigserver_host, " is unreachable.\n",
                      "No web-based data retrievals are possible.\n")
    showNotification(message, duration = NULL, closeButton = TRUE,
                     type = "warning")
  }

  # the_map (leaflet) is another client-specific (non-shared) variable:

  the_map <- NULL

  # Create the map:

  create_map <- function() {
    west <- west_bound(model)
    east <- east_bound(model)
    south <- south_bound(model)
    north <- north_bound(model)

    ASNAT_dprint("create_map: [%f, %f] [%f, %f]\n", west, east, south, north)

    # Note: minZoom = 2 prevents zooming out to 'replicated longitude' view -
    # continents are only shown once - as setMaxBounds() does not prevent this!
    # https://gis.stackexchange.com/questions/224383/
    # leaflet-maxbounds-doesnt-prevent-zooming-out

    result <- leaflet() %>%
      addTiles(options = list(minZoom = 2)) %>%
      fitBounds(west, south, east, north) %>%
      setMaxBounds(-180.0, -90.0, 180.0, 90.0) %>%
      addScaleBar(position = "topleft", options = list(imperial = FALSE))
    return(result)
  }

  the_map <- create_map()
  output$map <- renderLeaflet(the_map)


  # There is also a small site_neighbor_map that shows only the Dataset X
  # single selected site and its Dataset Y neighbors:

  the_site_neighbor_map <- create_map()
  output$site_neighbor_map <- renderLeaflet(the_site_neighbor_map)


  # Define function to get colors of values:

  data_colors <- function(values, minimum, maximum, colormap) {
    count <- length(values)
    result <- rep("black", count)
    colormap_size <- length(colormap)
    colormap_size_2 <- colormap_size - 2L

    if (maximum > minimum) {
      the_range <- maximum - minimum

      for (index in seq_along(values)) {
        value <- values[[index]]

        if (value > maximum) {
          result[[index]] <- colormap[[colormap_size]]
        } else if (value >= minimum) {
          normalized_value <- (value - minimum) / the_range
          normalized_index <-
            as.integer(trunc(colormap_size_2 * normalized_value)) + 2L

          if (normalized_index > colormap_size) {
            normalized_index <- colormap_size
          }

          result[[index]] <- colormap[[normalized_index]]
        }
      }
    }

    ASNAT_dprint("data_color(minimum = %f, maximum = %f):\n", minimum, maximum)
    ASNAT_dprint("values:")
    ASNAT_debug(str, values)
    ASNAT_dprint("colormap:")
    ASNAT_debug(str, colormap)
    ASNAT_dprint("data_color(): result:")
    ASNAT_debug(str, result)
    return(result)
  }



  # Define function to get AQI colors of values:

  aqi_data_colors <- function(values, breakpoints, colormap) {
    ASNAT_dprint("aqi_data_colors():")
    stopifnot(length(values) > 0L)
    stopifnot(length(breakpoints) > 0L)
    stopifnot(length(colormap) == length(breakpoints))
    ASNAT_dprint("values:")
    ASNAT_debug(str, values)
    ASNAT_dprint("breakpoints:")
    ASNAT_debug(str, breakpoints)
    ASNAT_dprint("colormap:")
    ASNAT_debug(str, colormap)

    count <- length(values)
    result <- rep("black", count)

    for (index in seq_along(values)) {
      value <- values[[index]]

      for (color_index in seq_along(breakpoints)) {
        aqi_breakpoint <- breakpoints[[color_index]]
        aqi_color <- colormap[[color_index]]

        if (value <= aqi_breakpoint) {
          result[[index]] <- aqi_color
          break
        }
      }
    }

    ASNAT_dprint("aqi_data_color(): result:")
    ASNAT_debug(str, result)
    return(result)
  }



  # Define function to draw 'glyph = source' legend on the map:
  # https://stackoverflow.com/questions/41512908/leaflet-legend-in-r-based-on-color-and-shape

  draw_glyph_source_legend_on_map <- function(a_map, sources) {
    ASNAT_dprint("In draw_glyph_source_legend_on_map(sources)\n")
    sources_html <- c()

    for (source in sources) {
      glyph <- map_glyph(source)
      file_name <- glyph_file_name(glyph, "black")
      source_label <- paste0("<img src='data:image/png;base64,",
                             base64enc::base64encode(file_name),
                             "' width='30'; height='30';> ",
                             source,
                             "<br/>")
      sources_html <- paste(sources_html, source_label, collapse = " ")
    }

    a_map <- addControl(map = a_map, html = sources_html,
                           position = "bottomright",
                           layerId = "source_legend")

    return(a_map)
  }



  # Define function to draw dataset-colored glyphs and legends on the map:

  draw_data_on_map <- function() {
    ASNAT_dprint("In draw_data_on_map()\n")
    timer <- ASNAT_start_timer()

    # Remove any existing data point glyphs and legends:

    # FIX: does not work! the_map <<- clearGroup(the_map, "glyphs_and_legends")
    # work-around:
    the_map <<- clearMarkers(the_map)
    the_map <<- clearControls(the_map)
    the_site_neighbor_map <<- clearMarkers(the_site_neighbor_map)
    the_site_neighbor_map <<- clearControls(the_site_neighbor_map)

    if (dataset_count(model) > 0L) {

      # Get the ranges for each units across all datasets:

      units <- dataset_units(model)
      count <- length(units)
      stopifnot(count == dataset_count(model))

      # Override actual data range with particular units ranges:

      minimums <- dataset_minimums(model)
      maximums <- dataset_maximums(model)

      if (count == 1L) {
        unit <- units[[1L]]

        if (unit == "%") {
          minimums <- c(0.0)
          maximums <- c(100.0)
        } else if (unit == "C") {
          minimums <- c(0.0)
          maximums <- c(35.0)
        } else if (unit != "hPa") {
          minimums <- c(0.0)
        }

      } else {
        stopifnot(length(minimums) == length(units))
        stopifnot(length(maximums) == length(units))

        for (index in 1L:count) {
          unit <- units[[index]]

          if (unit == "%") {
            minimum <- 0.0
            maximum <- 100.0
          } else if (unit == "C") {
            minimum <- 0.0
            maximum <- 35.0
          } else {

            if (unit != "hPa") {
              minimum <- 0.0
              minimums[[index]] <- minimum
            }

            minimum <- minimums[[index]]
            maximum <- maximums[[index]]

            for (index2 in index:count) {
              unit2 <- units[[index2]]

              if (unit2 == unit) {
                minimum2 <- minimums[[index2]]
                maximum2 <- maximums[[index2]]

                if (minimum2 < minimum) {
                  minimum <- minimum2
                }

                if (maximum2 > maximum) {
                  maximum <- maximum2
                }
              }
            }
          }

          for (index2 in 1:count) {
            unit2 <- units[[index2]]

            if (unit2 == unit) {
              minimums[[index2]] <- minimum
              maximums[[index2]] <- maximum
            }
          }
        }
      }

      match_timestamp <- timestamp(model)
      model_timestep_size <- timestep_size(model)

      if (model_timestep_size == "hours") {
        match_timestamp <- substr(match_timestamp, 1L, 13L)
      } else {
        match_timestamp <- substr(match_timestamp, 1L, 10L)
      }

      ASNAT_dprint("Filtering data by model_timestamp = %s\n", match_timestamp)
      the_unit <- NULL
      sources <- c()

      for (index in 1L:count) {
        ASNAT_dprint("dataset #%d:\n", index)
        the_dataset <- dataset(model, index)
        the_coverage <- coverage(the_dataset)
        parts <- unlist(strsplit(the_coverage, ".", fixed = TRUE))
        source <- parts[[1L]]
        variable <- variable_name(the_dataset)
        source_variable <- source_variable(the_dataset)
        unit <- units[[index]]
        the_data_frame <- data_frame(the_dataset)
        the_data_frame_timestamps <- the_data_frame[[1L]]
        matched_rows <- startsWith(the_data_frame_timestamps, match_timestamp)
        timestep_data_frame <- the_data_frame[matched_rows, ]
        columns <- ncol(timestep_data_frame)
        ASNAT_dprint("addMarkers() for %s(%s):\n", source_variable, unit)
        longitudes <- timestep_data_frame[[2L]]
        latitudes <- timestep_data_frame[[3L]]
        measure_column <- variable_column(the_dataset)
        values <- timestep_data_frame[[measure_column]]
        column_names <- colnames(timestep_data_frame)
        id_column <- ASNAT_site_column_index(column_names)
        ids <- timestep_data_frame[[id_column]]
        note_column <- length(column_names)
        notes <- timestep_data_frame[[note_column]]
        labels <- paste0(source, " = ", values, " id: ", ids, " ", notes)

        minimum <- minimums[[index]]
        maximum <- maximums[[index]]
        value_colors <- NULL
        selected_colormap_name <- legend_colormap(model)
        use_aqi <- selected_colormap_name == "AQI"

        if (use_aqi) {
          selected_colormap <- the_aqi_colormap

          if (startsWith(variable, "pm10")) {
            value_colors <-
              aqi_data_colors(values,
                              the_pm10_daily_aqi_breakpoints,
                              the_aqi_colormap)
          } else if (startsWith(variable, "pm1") ||
                     startsWith(variable, "pm25") ) {
            value_colors <-
              aqi_data_colors(values,
                              the_pm25_daily_aqi_breakpoints,
                              the_aqi_colormap)
          } else if (startsWith(variable, "ozone")) {

            if (timestep_size(model) == "hours") {
              value_colors <-
                aqi_data_colors(values,
                                the_ozone_1_hour_aqi_breakpoints,
                                the_aqi_colormap)
            } else {
              value_colors <-
                aqi_data_colors(values,
                                the_ozone_8_hour_aqi_breakpoints,
                                the_aqi_colormap)
            }
          } else {
            use_aqi <- FALSE
          }
        }

        if (is.null(value_colors)) {

          if (use_aqi) {
            selected_colormap <- the_aqi_colormap
          } else if (selected_colormap_name == "gray") {
            selected_colormap <- the_gray_colormap
          } else if (selected_colormap_name == "blue") {
            selected_colormap <- the_blue_colormap
          } else if (selected_colormap_name == "colorsafe") {
            selected_colormap <- the_colorsafe_colormap
          } else if (selected_colormap_name == "viridis") {
            selected_colormap <- the_viridis_colormap
          } else {
            selected_colormap <- the_default_colormap
          }

          value_colors <- data_colors(values, minimum, maximum, selected_colormap)
        }

        glyph <- map_glyph(the_coverage)
        glyph_file_template <- glyph_file_name(glyph, "black")
        point_glyph_files <- c()

        for (color in value_colors) {
          this_glyph_file <-
            gsub(fixed = TRUE, "black", color, glyph_file_template)
          point_glyph_files <- append(point_glyph_files, this_glyph_file)
        }

        enable_hover <- FALSE # Too intrusive/cluttered.
        enable_popup <- TRUE

        the_map <<- addMarkers(map = the_map,
                               lng = longitudes,
                               lat = latitudes,
                               group = "glyphs_and_legends",
                               data = values,
                               label = if (enable_hover) labels else NULL,
                               popup = if (enable_popup) labels else NULL,
                               icon = makeIcon(iconUrl = point_glyph_files,
                                               iconWidth = glyph_size,
                                               iconHeight = glyph_size,
                                               popupAnchorX = glyph_size %/% 2L,
                                               popupAnchorY = 0L))

        unmatched_units <- is.null(the_unit) || the_unit != unit
        ASNAT_dprint("index = %d, unmatched_units = %d\n",
                     index, as.integer(unmatched_units))

        if (unmatched_units) {
          the_unit <- unit
          variable_and_units <-
            paste0(fancy_legend_label(variable),
                   "(", fancy_legend_label(unit), ")")
          tick_values <- NULL
          legend_colors <- NULL

          if (use_aqi) {
            tick_values <- rev(the_aqi_names)
            legend_colors <- rev(the_aqi_colormap)
          } else {
            the_minimum <- minimums[[1L]]
            the_maximum <- maximums[[1L]]
            the_range <- the_maximum - the_minimum
            the_increment <- the_range / (length(selected_colormap) - 2L)
            tick_values <- double(0)
            tick_values <- append(tick_values, -1.0)
            the_tick_value <- the_minimum

            for (index in 2L:length(selected_colormap) - 1L) {
              tick_values <- append(tick_values, the_tick_value)
              the_tick_value <- the_tick_value + the_increment
            }

            tick_values <- round(tick_values, digits = 2L)
            tick_values <- as.character(tick_values)
            tick_values[1L] <- paste0("<", round(the_minimum, digits = 2L))
            the_length <- length(tick_values)
            tick_values[the_length] <- paste0(">", round(the_maximum, digits = 2L))

            # Legend colors must be ordered top-down (high-low) so reverse them:

            tick_values <- rev(tick_values)
            legend_colors <- rev(selected_colormap)
          }

          ASNAT_dprint("calling addLegend()\n")
          the_map <<-
            addLegend(map = the_map, position = "bottomright",
                      group = "glyphs_and_legends",
                      values = NULL,
                      colors = legend_colors,
                      labels = tick_values,
                      title = variable_and_units,
                      opacity = 1.0)
        }

        sources <- append(sources, source)
      }

      # Add legend showing glyph = source:

      unique_sources <- unique(sources)
      the_map <<- draw_glyph_source_legend_on_map(the_map, unique_sources)
    }

    ASNAT_elapsed_timer("draw_data_on_map", timer)
    return(the_map)
  }



  # Define function to draw timestamp on the map:

  draw_timestamp_on_map <- function() {
    ASNAT_dprint("In draw_timestamp_on_map()\n")

    # Draw the timestamp on the map as YYYY-MM-DD HH:00 UTC:

    the_timestamp <- timestamp(model)
    yyyy_mm_dd <- substr(the_timestamp, 1L, 10L)
    hh_mm <- substr(the_timestamp, 12L, 16L)
    the_label <- yyyy_mm_dd

    if (timestep_size(model) == "hours") {
      the_label <- paste(the_label, hh_mm)
    }

    the_label <- paste(the_label, "UTC")

    timestamp_label <- paste0("<label>", the_label, "</label>")
    timestamp_html <- tags$div(HTML(timestamp_label))
    the_map <<- addControl(map = the_map, html = timestamp_html,
                           position = "bottomleft",
                           layerId = "timestamp")
    return(the_map)
  }



  # Update Purple Air Sites Menu for changed viewing area:

  update_purple_air_sites_menu <- function() {
    selection <- all_purple_air_sites

    is_valid_input <-
      shiny::isTruthy(input$purple_air_sites_menu) &&
      !is.na(input$purple_air_sites_menu) &&
      nchar(input$purple_air_sites_menu) > 0L

    if (is_valid_input) {
      selection <- input$purple_air_sites_menu
    }

    sites <- append(all_purple_air_sites, purple_air_sites(model))
    found_index <- grep(fixed = TRUE, selection, sites)

    if (length(found_index) == 1L) {
      selection <- sites[[found_index]]
    } else {
      selection <- all_purple_air_sites
    }

    ASNAT_dprint("updating selectizeInput() in server() with %d items.\n",
                 length(sites))

    freezeReactiveValue(input, "purple_air_sites_menu")
    updateSelectizeInput(session, "purple_air_sites_menu",
                         choices = sites, server = TRUE)
  }



  # Redraw/zoom the site_neighbors_map based on selected Dataset X site:

  update_site_neighbors_map <- function(selected_dataset_x_site) {

    the_site_neighbor_map <<- clearMarkers(the_site_neighbor_map) # Glyphs.
    the_site_neighbor_map <<- clearControls(the_site_neighbor_map) #  Legend.

    if (selected_dataset_x_site == 0L) {
      shinyjs::hide(id = "site_neighbor_map")
      shinyjs::hide(id = "show_site_labels")
    } else {
      shinyjs::show(id = "site_neighbor_map")
      shinyjs::show(id = "show_site_labels")

      # If a single site is selected then get sources and zoom to neighbors:

      model_comparison_data_frame <- comparison_data_frame(model)
      model_summary_y_data_frame <- summary_y_data_frame(model)

      if (!is.null(model_comparison_data_frame) &&
          !is.null(model_summary_y_data_frame) &&
          ASNAT_units_match(input$dataset_x_variable_menu[1L],
                            input$dataset_y_variable_menu[1L])) {

        dataset_x_name <- input$dataset_x_menu[1L]
        dataset_x <- find_dataset(model, dataset_x_name)
        source_x <- coverage_source(dataset_x)

        dataset_y_name <- input$dataset_y_menu[1L]
        dataset_y <- find_dataset(model, dataset_y_name)
        source_y <- coverage_source(dataset_y)

        sources <- source_x

        if (source_y != source_x) {
          sources <- c(source_x, source_y)
        }

        # Get Dataset Y neighbor sites:
        # model_comparison_data_frame columns are:
        # 1 = time, 2 = id_x, 3 = measure_x, 4 = id_y, 5 = measure_y, 6 = flag_y

        matched_rows <-
          which(model_comparison_data_frame[[2L]] == selected_dataset_x_site)
        subset_data_frame <- model_comparison_data_frame[matched_rows, ]
        y_neighbor_ids <- subset_data_frame[[4L]]
        y_neighbor_ids <- unique(sort.int(y_neighbor_ids))

        # Get location and note of selected_dataset_x_site:


        data_frame_x <- data_frame(dataset_x)
        column_names <- colnames(data_frame_x)
        site_column <- ASNAT_site_column_index(column_names)
        matched_rows <-
          which(data_frame_x[[site_column]] == selected_dataset_x_site)
        subset_data_frame_x <- data_frame_x[matched_rows, ]
        longitudes <- subset_data_frame_x[[2L]]
        latitudes <- subset_data_frame_x[[3L]]
        longitude_x <- longitudes[[1L]]
        latitude_x <- latitudes[[1L]]
        last_column <- ncol(subset_data_frame_x)
        notes_x <- subset_data_frame_x[[last_column]]
        note_x <- notes_x[[1L]]
        west <- longitude_x
        east <- longitude_x
        south <- latitude_x
        north <- latitude_x

        # Get location and note of neighbor sites:

        data_frame_y <- data_frame(dataset_y)
        column_names <- colnames(data_frame_y)
        site_column <- ASNAT_site_column_index(column_names)
        last_column <- ncol(data_frame_y)
        neighbor_sites <- c()
        neighbor_notes <- c()
        neighbor_longitudes <- c()
        neighbor_latitudes <- c()

        for (y_neighbor_id in y_neighbor_ids ) {
          matched_rows <- which(data_frame_y[[site_column]] == y_neighbor_id)
          subset_data_frame_y <- data_frame_y[matched_rows, ]
          notes <- subset_data_frame_y[[last_column]]
          longitudes <- subset_data_frame_y[[2L]]
          latitudes <- subset_data_frame_y[[3L]]
          note <- notes[[1L]]
          longitude <- longitudes[[1L]]
          latitude <- latitudes[[1L]]
          neighbor_sites <- append(neighbor_sites, y_neighbor_id)
          neighbor_notes <- append(neighbor_notes, note)
          neighbor_longitudes <- append(neighbor_longitudes, longitude)
          neighbor_latitudes <- append(neighbor_latitudes, latitude)
          west <- min(west, longitude)
          east <- max(east, longitude)
          south <- min(south, latitude)
          north <- max(north, latitude)
        }

        # Zoom map to selected site and neighbors:

        the_site_neighbor_map <<-
          fitBounds(the_site_neighbor_map, west, south, east, north)

        # Draw selected site and on the map:

        coverage_x <- coverage(dataset_x)
        glyph <- map_glyph(coverage_x)
        glyph_file_template <- glyph_file_name(glyph, "black")
        glyph_icon <- makeIcon(iconUrl = glyph_file_template,
                               iconWidth = glyph_size,
                               iconHeight = glyph_size,
                               popupAnchorX = glyph_size %/% 2L,
                               popupAnchorY = 0L)

        model_show_site_labels <- show_site_labels(model)

        if (model_show_site_labels) {
          label_options <-
            labelOptions(noHide = TRUE, direction = "bottom",
                         style = list("font-size" = "9px"))
          the_site_neighbor_map <<-
            addMarkers(map = the_site_neighbor_map,
                         lng = longitude_x,
                         lat = latitude_x,
                         group = "glyphs_and_legends",
                         data = selected_dataset_x_site,
                         label = selected_dataset_x_site,
                         labelOptions = label_options,
                         icon = glyph_icon)
        }

        label_x <-
          paste0(source_x, " = id: ", selected_dataset_x_site, " ", note_x)
        enable_hover <- TRUE
        enable_popup <- TRUE
        label_options <- labelOptions(noHide = FALSE, direction = "bottom")

        the_site_neighbor_map <<-
          addMarkers(map = the_site_neighbor_map,
                     lng = longitude_x,
                     lat = latitude_x,
                     group = "glyphs_and_legends",
                     data = selected_dataset_x_site,
                     label = if (enable_hover) label_x else NULL,
                     popup = if (enable_popup) label_x else NULL,
                     labelOptions = label_options,
                     icon = glyph_icon)

        # Draw neighbor sites on the map:

        coverage_y <- coverage(dataset_y)
        glyph <- map_glyph(coverage_y)
        # Gray markers are harder to see in the map. Just use black and rely on
        # shape and optional id to discern single X site from Y neighbors.
        # neighbor_color <- the_gray_colormap[[length(the_gray_colormap) - 3L]]
        neighbor_color <- "black"
        glyph_file_template <- glyph_file_name(glyph, neighbor_color)
        glyph_icon <- makeIcon(iconUrl = glyph_file_template,
                               iconWidth = glyph_size,
                               iconHeight = glyph_size,
                               popupAnchorX = glyph_size %/% 2L,
                               popupAnchorY = 0L)
        id_labels <- neighbor_sites
        labels <-
          paste0(source_y, " = id: ", neighbor_sites, " ", neighbor_notes)

        if (model_show_site_labels) {
          label_options <-
            labelOptions(noHide = TRUE, direction = "bottom",
                         style = list("font-size" = "9px"))
          the_site_neighbor_map <<-
            addMarkers(map = the_site_neighbor_map,
                       lng = neighbor_longitudes,
                       lat = neighbor_latitudes,
                       group = "glyphs_and_legends",
                       data = neighbor_sites,
                       label = id_labels,
                       labelOptions = label_options,
                       icon = glyph_icon)
        }

        label_options <- labelOptions(noHide = FALSE, direction = "bottom")
        the_site_neighbor_map <<-
          addMarkers(map = the_site_neighbor_map,
                     lng = neighbor_longitudes,
                     lat = neighbor_latitudes,
                     group = "glyphs_and_legends",
                     data = neighbor_sites,
                     label = if (enable_hover) labels else NULL,
                     popup = if (enable_popup) labels else NULL,
                     labelOptions = label_options,
                     icon = glyph_icon)


        # Add legend showing glyph = source of comparison Dataset X, Dataset Y:

        the_site_neighbor_map <<-
          draw_glyph_source_legend_on_map(the_site_neighbor_map, sources)
      }
    }

    output$site_neighbor_map <- renderLeaflet(the_site_neighbor_map)
  }



  # Update Neighbors Menu for changed neighbors:

  update_neighbors_menu <- function() {
    selection <- all_dataset_x_neighbor_sites
    sites <- selection

    is_valid_input <-
      shiny::isTruthy(input$neighbors_menu) &&
      !is.na(input$neighbors_menu) &&
      nchar(input$neighbors_menu) > 0L

    if (is_valid_input) {
      selection <- input$neighbors_menu
    }

    dataset_x_name <- input$dataset_x_menu[1L]

    if ( !is.null(dataset_x_name)) {
      neighbor_ids_notes <- dataset_x_neighbors_id_note(model, dataset_x_name)

      if (!is.null(neighbor_ids_notes)) {
        sites <- append(all_dataset_x_neighbor_sites, neighbor_ids_notes)
      }
    }

    found_index <- grep(fixed = TRUE, selection, sites)
    selected_site <- 0L

    if (length(found_index) == 1L) {
      selection <- sites[[found_index]]
      parts <- unlist(strsplit(selection, " "))
      selected_site <- as.integer(parts[[1L]])
    } else {
      selection <- all_dataset_x_neighbor_sites
    }

    update_site_neighbors_map(selected_site)

    ASNAT_dprint("updating selectizeInput() in server() with %d items.\n",
                 length(sites))
    freezeReactiveValue(input, "neighbors_menu")
    updateSelectizeInput(session, "neighbors_menu",
                         choices = sites, server = TRUE)
  }



  observeEvent(input$noDataInfo, {
    shinyjs::runjs("swal.close();")
  })


  # Callback for show site labels checkbox:

  observeEvent(input$show_site_labels, {

    if (shiny::isTruthy(input$show_site_labels)) {
      show_site_labels(model) <<- TRUE
    } else {
      show_site_labels(model) <<- FALSE
    }

    is_valid_input <-
      shiny::isTruthy(input$neighbors_menu) &&
      !is.na(input$neighbors_menu) &&
      nchar(input$neighbors_menu) > 0L
    selected_site <- 0L

    if (is_valid_input) {
      parts <- unlist(strsplit(input$neighbors_menu, " "))
      first_part <- parts[[1L]]
      selected_site <- as.integer(first_part)
    }

    if (selected_site > 0L) {
      update_site_neighbors_map(selected_site)
    }
  })



  # Callback for purple_air_sites_menu:

  observeEvent(input$neighbors_menu, {
    ASNAT_dprint("In neighbors_menu callback.\n")
    is_valid_input <-
      shiny::isTruthy(input$neighbors_menu) &&
      !is.na(input$neighbors_menu) &&
      nchar(input$neighbors_menu) > 0L
    selected_site <- 0L

    if (is_valid_input) {
      parts <- unlist(strsplit(input$neighbors_menu, " "))
      first_part <- parts[[1L]]
      selected_site <- as.integer(first_part)
    }

    update_site_neighbors_map(selected_site)
  })



  # Callback for Quit button:

  observeEvent(input$quit, {
    on_quit()
    # https://github.com/daattali/advanced-shiny/blob/master/close-window/app.R
    js$closeWindow()
    ASNAT_dprint("Calling stopApp().\n")
    stopApp()
  })



  # Callback for map pan/zoom events:

  observeEvent(input$map_bounds, {
    ASNAT_dprint("In callback for map_bounds:\n")
    bounds_list <- input$map_bounds
    west <- bounds_list$west
    east <- bounds_list$east
    south <- bounds_list$south
    north <- bounds_list$north
    ASNAT_dprint("map: [%f, %f] [%f, %f]\n", west, east, south, north)

    # Check and adjust map bounds to stay within 'non-replicated view'
    # (that does not cross the +/-180 line) then update the model bounds:

    adjust <- FALSE
    delta <- 0.0 # 0.001

    if (west == east) {
      east <- west + 1.0
      adjust <- TRUE
    }

    if (south == north) {
      north <- south + 1.0
      adjust <- TRUE
    }

    if (west <= -180.0) {
      west <- -179.0 + delta
      adjust <- TRUE
    }

    if (east >= 180.0) {
      east <- 179.0 - delta
      adjust <- TRUE
    }

    if (south <= -90.0) {
      south <- -89.0 + delta
      adjust <- TRUE
    }

    if (north >= 90.0) {
      north <- 89.0 - delta
      adjust <- TRUE
    }

    #if (adjust || (east - west) < delta || (north - south) < delta) {
      west <- west - delta
      east <- east + delta
      south <- south - delta
      north <- north + delta
    #}

    the_map <<- fitBounds(the_map, west, south, east, north)
    #the_map <<- flyToBounds(the_map, west, south, east, north)

    ASNAT_dprint("adjust = %d, setting to [%f, %f] [%f, %f]\n",
                 as.integer(adjust), west, east, south, north)
    west_bound(model) <<- west
    east_bound(model) <<- east
    south_bound(model) <<- south
    north_bound(model) <<- north
    ASNAT_dprint("set model: [%f, %f] [%f, %f]\n",
                 west_bound(model), east_bound(model),
                 south_bound(model), north_bound(model))
    update_purple_air_sites_menu()
  })



  # Callback for reset map bounds:

  observeEvent(input$reset_map, {
    ASNAT_dprint("In reset_map callback.\n")

    # Zoom to New York City - Long Island:

    west <- -74.3
    east <- -72.7
    south <- 40.5
    north <- 41.4
    longitude_center <- (west + east) * 0.5
    latitude_center <- (south + north) * 0.5
    ASNAT_dprint("map: [%f, %f] [%f, %f]\n", west, east, south, north)
    the_map <<- fitBounds(the_map, west, south, east, north)
    the_map <<- flyToBounds(the_map, west, south, east, north)
    the_map <<- setView(the_map, longitude_center, latitude_center, zoom = 9L)
    the_site_neighbor_map <<- fitBounds(the_site_neighbor_map, west, south, east, north)
    the_site_neighbor_map <<- flyToBounds(the_site_neighbor_map, west, south, east, north)
    the_site_neighbor_map <<- setView(the_site_neighbor_map, longitude_center, latitude_center, zoom = 9L)
    timer <- ASNAT_start_timer()
    output$map <- renderLeaflet(the_map)
    output$site_neighbor_map <- renderLeaflet(the_site_neighbor_map)
    ASNAT_elapsed_timer("render map:", timer)
    west_bound(model) <<- west
    east_bound(model) <<- east
    south_bound(model) <<- south
    north_bound(model) <<- north
    ASNAT_dprint("model: [%f, %f] [%f, %f]\n",
                 west_bound(model), east_bound(model),
                 south_bound(model), north_bound(model))
    update_purple_air_sites_menu()
  })



  # Helper for map click events:

  print_map_click_info <- function(click_list, bounds_list) {

    longitude <- click_list$lng
    latitude <- click_list$lat
    west <- bounds_list$west
    east <- bounds_list$east
    south <- bounds_list$south
    north <- bounds_list$north
    the_width_height <- ASNAT_width_height(west, east, south, north)
    width_meters <- the_width_height$width
    height_meters <- the_width_height$height
    message_text <-
      sprintf("map %0.0fm x %0.0fm [%f, %f] [%f, %f] (%f, %f)\n",
              width_meters, height_meters,
              west, east, south, north, longitude, latitude)
    output$message_area <- renderPrint({cat(message_text, sep = "\n")})
  }



  # Callback for map click events:

  observeEvent(input$map_click, {
    ASNAT_dprint("In callback for map_click:\n")
    print_map_click_info(input$map_click, input$map_bounds)
  })


  # Callback for site_neighbor_map click events:

  observeEvent(input$site_neighbor_map_click, {
    ASNAT_dprint("In callback for site_neighbor_map_click:\n")
    print_map_click_info(input$site_neighbor_map_click,
                         input$site_neighbor_map_bounds)
  })



  # Callback for Start Date:

  observeEvent(input$start_date, {
    ASNAT_dprint("In start_date callback.\n")

    is_valid_input <-
      shiny::isTruthy(input$start_date) &&
      ASNAT_is_valid_date(input$start_date)

    model_start_date <- start_date(model)

    if (!is_valid_input) {
      tomorrow <- Sys.Date() + 1L
      freezeReactiveValue(input, "start_date")
      updateDateInput(session = session, inputId = "start_date",
                      value = model_start_date,
                      min = "1970-01-01", max = tomorrow)
    } else {
      start_date(model) <<- input$start_date

      # Draw data for timestep if there is any:

      if (dataset_count(model) > 0L) {
        the_map <<- draw_data_on_map()
      }

      the_map <<- draw_timestamp_on_map()
      timer <- ASNAT_start_timer()
      output$map <- renderLeaflet(the_map)
      ASNAT_elapsed_timer("render map:", timer)
    }

    ASNAT_dprint("start_date(model) = %s\n", as.character(start_date(model)))
  })



  # Callback for Days:

  observeEvent(input$days, {
    ASNAT_dprint("In days callback.\n")
    ASNAT_debug(str, list(input$days))
    # BUG in numericInput(): min, max are not enforced!
    # https://github.com/rstudio/shiny/issues/3689
    # HACK work-around:

    is_valid_input <-
      shiny::isTruthy(input$days) &&
      !is.na(input$days) &&
      input$days >= 1L &&
      input$days <= 366L

    ASNAT_dprint("is_valid_input = %d\n", as.integer(is_valid_input))

    if (!is_valid_input) {
      model_days <- days(model)
      ASNAT_dprint("Reseting invalid input to model_days = %d\n", model_days)
      freezeReactiveValue(input, "days")
      updateNumericInput(session = session, inputId = "days",
                         value = model_days)
    } else {
      ASNAT_dprint("Setting days(model) = %d\n", input$days)
      days(model) <<- input$days
      ASNAT_dprint("Set days(model) = %d\n", days(model))

      last_model_timestep <- timesteps(model) - 1L

      is_valid_input <-
        shiny::isTruthy(input$timestep_slider) &&
        !is.na(input$timestep_slider) &&
        input$timestep_slider >= 0L &&
        input$timestep_slider <= last_model_timestep

      new_timestep_value <- last_model_timestep

      if (is_valid_input) {
        new_timestep_value <- input$timestep_slider
      }

      ASNAT_dprint("Reseting timestep_slider to new_timestep_value = %d\n",
                   new_timestep_value)
      freezeReactiveValue(input, "timestep_slider")
      updateSliderInput(session = session, inputId = "timestep_slider",
                        value = new_timestep_value,
                        min = 0L, max = last_model_timestep, step = 1L)
    }

    ASNAT_dprint("returning with:\n")
    ASNAT_dprint("timestep_size(model) = %s\n", timestep_size(model))
    ASNAT_dprint("days(model) = %d\n", days(model))
    ASNAT_dprint("timesteps(model) = %d\n", timesteps(model))
    ASNAT_dprint("timestep(model) = %d\n", timestep(model))
  })



  # Callback for Timestep Size:

  observeEvent(input$timestep_size, {
    ASNAT_dprint("In timestep_size callback.\n")
    ASNAT_debug(str, list(input$timestep_size))

    if (shiny::isTruthy(input$timestep_size) &&
        input$timestep_size == "hours" ||
        input$timestep_size == "days") {
      timestep_size(model) <<- input$timestep_size
      ASNAT_dprint("Set timestep_size(model) = %s\n", timestep_size(model))
      model_timestep <- timestep(model)
      last_model_timestep <- timesteps(model) - 1L
      ASNAT_dprint("Reseting timestep_slider to %d, last_model_timestep = %d\n",
                   model_timestep, last_model_timestep)
      freezeReactiveValue(input, "timestep_slider")
      updateSliderInput(session = session, inputId = "timestep_slider",
                        value = model_timestep,
                        min = 0L, max = last_model_timestep, step = 1L)
    }

    ASNAT_dprint("returning with:\n")
    ASNAT_dprint("timestep_size(model) = %s\n", timestep_size(model))
    ASNAT_dprint("days(model) = %d\n", days(model))
    ASNAT_dprint("timesteps(model) = %d\n", timesteps(model))
    ASNAT_dprint("timestep(model) = %d\n", timestep(model))
  })



  # Helper: clear tables and plots:

  clear_tables_and_plots <- function() {
    output$table1 <- renderTable({NULL})
    output$table2 <- renderTable({NULL})
    output$table3 <- renderTable({NULL})
    output$table4 <- renderTable({NULL})

    output$boxplot_x <- renderPlot({NULL})
    output$timeseriesplot_x <- renderPlot({NULL})
    output$boxplot_y <- renderPlot({NULL})
    output$timeseriesplot_y <- renderPlot({NULL})
    output$scatterplot_xy <- renderPlot({NULL})
    output$scatterplot_xy_unflagged <- renderPlot({NULL})

    output$interactive_boxplot_x <- renderPlot({NULL})
    output$interactive_timeseriesplot_x <- renderPlot({NULL})
    output$interactive_boxplot_y <- renderPlot({NULL})
    output$interactive_timeseriesplot_y <- renderPlot({NULL})
    output$interactive_scatterplot_xy <- renderPlot({NULL})
    output$interactive_scatterplot_xy_unflagged <- renderPlot({NULL})
  }



  # Callback for Delete All Loaded Data button:

  observeEvent(input$delete_data, {
    ASNAT_dprint("In delete_data callback.\n")
    model <<- delete_datasets(model)
    ASNAT_dprint("model dataset count = %d\n", dataset_count(model))

    # Clear the Dataset X/Y selections menu:

    freezeReactiveValue(input, "dataset_x_menu")
    freezeReactiveValue(input, "dataset_x_variable_menu")
    freezeReactiveValue(input, "dataset_y_menu")
    freezeReactiveValue(input, "dataset_y_variable_menu")
    updateSelectInput(session = session, inputId = "dataset_x_menu",
                      choices = character(0), selected = character(0))
    updateSelectInput(session = session, inputId = "dataset_x_variable_menu",
                      choices = character(0), selected = character(0))
    updateSelectInput(session = session, inputId = "dataset_y_menu",
                      choices = character(0), selected = character(0))
    updateSelectInput(session = session, inputId = "dataset_y_variable_menu",
                      choices = character(0), selected = character(0))

    # Clear the map data glyphs and legends:

    # FIX: the_map <<- clearGroup(the_map, "glyphs_and_legends")
    the_map <<- clearMarkers(the_map) # Clear all glyphs.
    the_map <<- clearControls(the_map) # This clears legends and the timestamp!
    the_map <<- draw_timestamp_on_map() # So add timestamp back.

    # Also clear the_site_nieghbor_map

    the_site_neighbor_map <<- clearMarkers(the_site_neighbor_map) # Glyphs.
    the_site_neighbor_map <<- clearControls(the_site_neighbor_map) #  Legend.

    output$map <- renderLeaflet(the_map)
    output$site_neighbor_map <- renderLeaflet(the_site_neighbor_map)

    # FIX: Map sometimes zooms out and sometimes won't display or zoom
    # and bounds collapse to a point. User must click Reset Map button.

    clear_tables_and_plots()
  })



  # Callback for purple_air_key:

  observeEvent(input$purple_air_key, {
    ASNAT_dprint("In purple_air_key callback.\n")
    key <- input$purple_air_key

    if (ASNAT_is_conforming_purple_air_key(key)) {
      purple_air_key(model) <<- key
    } else {
      warning_text <- "Non-conforming PurpleAir Key."
      warning(warning_text, call. = FALSE, immediate. = TRUE, noBreaks. = FALSE)
    }
  })



  # Callback for purple_air_sites_menu:

  observeEvent(input$purple_air_sites_menu, {
    ASNAT_dprint("In purple_air_sites_menu callback.\n")
    is_valid_input <-
      shiny::isTruthy(input$purple_air_sites_menu) &&
      !is.na(input$purple_air_sites_menu) &&
      nchar(input$purple_air_sites_menu) > 0L

    current_sensor_id <- purple_air_sensor(model)
    new_sensor_id <- -1L

    if (is_valid_input) {
      parts <- unlist(strsplit(input$purple_air_sites_menu, " "))
      first_part <- parts[[1L]]
      new_sensor_id <- as.integer(first_part)
    }

    if (new_sensor_id >= 0L && new_sensor_id != current_sensor_id) {
      purple_air_sensor(model) <<- new_sensor_id
    }
  })



  # Callback for Maximum neighbor distance:

  observeEvent(input$maximum_neighbor_distance, {
    ASNAT_dprint("In maximum_neighbor_distance callback.\n")
    ASNAT_debug(str, list(input$maximum_neighbor_distance))

    is_valid_input <-
      shiny::isTruthy(input$maximum_neighbor_distance) &&
      !is.na(input$maximum_neighbor_distance) &&
      input$maximum_neighbor_distance >= 0.0 &&
      input$maximum_neighbor_distance <= 10000.0

    ASNAT_dprint("is_valid_input = %d\n", as.integer(is_valid_input))

    if (!is_valid_input) {
      model_maximum_neighbor_distance <- maximum_neighbor_distance(model)
      ASNAT_dprint("Reseting invalid input to maximum_neighbor_distance = %f\n",
                   model_maximum_neighbor_distance)
      freezeReactiveValue(input, "maximum_neighbor_distance")
      updateNumericInput(session = session,
                         inputId = "maximum_neighbor_distance",
                         value = model_maximum_neighbor_distance)
    } else {
      ASNAT_dprint("Setting maximum_neighbor_distance(model) = %f\n",
                   input$maximum_neighbor_distance)
      maximum_neighbor_distance(model) <<- input$maximum_neighbor_distance
      ASNAT_dprint("Set maximum_neighbor_distance(model) = %f\n",
                   maximum_neighbor_distance(model))
    }

    ASNAT_dprint("returning with:\n")
    ASNAT_dprint("maximum_neighbor_distance(model) = %f\n",
                 maximum_neighbor_distance(model))
  })



  # Helper function to update X/Y selection menus when datasets have changed:

  update_dataset_x_y_selections <- function() {
    ASNAT_dprint("update_dataset_x_y_selections called.\n")

    count <- dataset_count(model)
    ASNAT_dprint("  dataset_count(model)) = %d\n", count)

    # If no datasets are loaded then clear the X/Y selection menus:

    if (count == 0L) {
      freezeReactiveValue(input, "dataset_x_menu")
      freezeReactiveValue(input, "dataset_x_variable_menu")
      freezeReactiveValue(input, "dataset_y_menu")
      freezeReactiveValue(input, "dataset_y_variable_menu")
      updateSelectInput(session = session, inputId = "dataset_x_menu",
                        choices = character(0), selected = character(0))
      updateSelectInput(session = session, inputId = "dataset_x_variable_menu",
                        choices = character(0), selected = character(0))
      updateSelectInput(session = session, inputId = "dataset_y_menu",
                        choices = character(0), selected = character(0))
      updateSelectInput(session = session, inputId = "dataset_y_variable_menu",
                        choices = character(0), selected = character(0))
      output$dataset_content_to_flag = renderDT({NULL})
      ASNAT_dprint("cleared dataset_x/y_menus.\n")
    } else {

      # List possibly different datasets in the X/Y selection menus:

      loaded_coverages <- dataset_coverages(model)
      available_datasets_x <- loaded_coverages
      available_datasets_y <- c("none", loaded_coverages)

      reset_x <-
        is.null(input$dataset_x_menu[1L]) ||
        nchar(input$dataset_x_menu[1L]) == 0L ||
        !(input$dataset_x_menu[1L] %in% available_datasets_x)

      ASNAT_dprint("reset_x = %d.\n", reset_x)

      if (reset_x) {

        # Reset dataset x to the 1st dataset:

        selected_dataset_x <- available_datasets_x[[1L]]
        dataset_x <- dataset(model, 1L)
        data_frame_x <- data_frame(dataset_x)
        column_names_x <- colnames(data_frame_x)
        available_variables_x <- ASNAT_variable_column_names(column_names_x)
        selected_column_x <- variable_column(dataset_x)
        selected_variable_x <- column_names_x[[selected_column_x]]

        # Must call freezeReactiveValue() for this update to work!
        # https://mastering-shiny.org/action-dynamic.html#freezing-reactive-inputs
        # HACK: but if freezeReactiveValue() is called this routine loops!
        #freezeReactiveValue(input, "dataset_x_menu")
        #freezeReactiveValue(input, "dataset_x_variable_menu")
        updateSelectInput(session = session,
                          inputId = "dataset_x_menu",
                          choices = available_datasets_x,
                          selected = selected_dataset_x)
        updateSelectInput(session = session,
                          inputId = "dataset_x_variable_menu",
                          choices = available_variables_x,
                          selected = selected_variable_x)

      } else if (length(available_datasets_x) > length(input$dataset_x_menu)) {

        # No change to selection, but expand choices to include new datasets:

        #freezeReactiveValue(input, "dataset_x_menu")
        updateSelectInput(session = session,
                          inputId = "dataset_x_menu",
                          choices = available_datasets_x,
                          selected = input$dataset_x_menu)
      }

      reset_y <-
        is.null(input$dataset_y_menu[1L]) ||
        nchar(input$dataset_y_menu[1L]) == 0L ||
        (input$dataset_y_menu[1L] != "none" &&
        !(input$dataset_y_menu[1L] %in% available_datasets_y))

      ASNAT_dprint("reset_y = %d.\n", reset_y)

      if (reset_y) {

        # Reset dataset y to none:

        selected_dataset_y <- "none"

        #freezeReactiveValue(input, "dataset_y_menu")
        #freezeReactiveValue(input, "dataset_y_variable_menu")
        updateSelectInput(session = session,
                          inputId = "dataset_y_menu",
                          choices = available_datasets_y,
                          selected = selected_dataset_y)
        updateSelectInput(session = session,
                          inputId = "dataset_y_variable_menu",
                          choices = character(0),
                          selected = character(0))

      } else if (input$dataset_y_menu[1L] != "none" &&
                 length(input$dataset_y_variable_menu) == 0L) {

        # User choose a valid dataset and variable menu needs updating:

        selected_dataset_y <- input$dataset_y_menu[1L]

        dataset_y_index <- which(loaded_coverages == selected_dataset_y)
        dataset_y <- dataset(model, dataset_y_index)
        data_frame_y <- data_frame(dataset_y)
        column_names_y <- colnames(data_frame_y)
        available_variables_y <- ASNAT_variable_column_names(column_names_y)
        selected_column_y <- variable_column(dataset_y)
        selected_variable_y <- column_names_y[[selected_column_y]]

        #freezeReactiveValue(input, "dataset_y_variable_menu")
        updateSelectInput(session = session,
                          inputId = "dataset_y_variable_menu",
                          choices = available_variables_y,
                          selected = selected_variable_y)

      } else if (length(available_datasets_y) > length(input$dataset_y_menu)) {

        # No change to selection, but expand choices to include new datasets:

        #freezeReactiveValue(input, "dataset_y_menu")
        updateSelectInput(session = session,
                          inputId = "dataset_y_menu",
                          choices = available_datasets_y,
                          selected = input$dataset_y_menu)
      }
    }

    # Update flag dataset menu and table:

    if (!is.null(input$dataset_y_menu[1L]) &&
        nchar(input$dataset_y_menu[1L]) > 0L &&
        input$dataset_y_menu[1L] != "none") {

      # Automatically choose Dataset Y to flag and show it:

      updateSelectInput(session = session,
                        inputId = "flag_dataset_menu",
                        # choices = c("Dataset X", "Dataset Y"),
                        selected = "Dataset Y")
      show_dataset_content_to_flag()
    } else if (!is.null(input$dataset_x_menu[1L]) &&
               nchar(input$dataset_x_menu[1L]) > 0L) {
      updateSelectInput(session = session,
                        inputId = "flag_dataset_menu",
                        # choices = c("Dataset X", "Dataset Y"),
                        selected = "Dataset X")
      show_dataset_content_to_flag()
    }

    ASNAT_dprint("update_dataset_x_y_selections returning.\n")
  }



  # Helper function for dataset_y/x_menu selections:

  handle_dataset_menu_selections <-
  function(dataset_menu, dataset_variable_menu, dataset_variable_menu_name) {
    ASNAT_dprint("In handle_dataset_menu_selections().\n")
    stopifnot(nchar(dataset_variable_menu_name) > 0L)

    is_valid_input <-
      shiny::isTruthy(dataset_menu) &&
      !is.na(dataset_menu) &&
      nchar(dataset_menu[1L]) >= 3L &&
      dataset_menu[1L] != "none" &&
      shiny::isTruthy(dataset_variable_menu) &&
      !is.na(dataset_variable_menu) &&
      nchar(dataset_variable_menu[1L]) > 0L &&
      dataset_count(model) > 0L

    ASNAT_dprint("is_valid_input = %d\n", as.integer(is_valid_input))

    if (!is_valid_input) {
      update_dataset_x_y_selections()
    } else {
      loaded_coverages <- dataset_coverages(model)
      dataset_name <- dataset_menu[[1L]]
      dataset_index <- which(loaded_coverages == dataset_name)

      if (dataset_index == 0L) {
        update_dataset_x_y_selections()
      } else {
        selected_dataset <- dataset(model, dataset_index)
        selected_column <- variable_column(selected_dataset)
        data_frame <- data_frame(selected_dataset)
        column_names <- colnames(data_frame)
        selected_variable <- column_names[[selected_column]]
        new_selected_variable <- dataset_variable_menu[[1L]]

        if (new_selected_variable != selected_variable) {
          available_variables <- ASNAT_variable_column_names(column_names)
          is_valid_input <- new_selected_variable %in% available_variables

          if (!is_valid_input) {
            freezeReactiveValue(input, dataset_variable_menu_name)
            updateSelectInput(session = session,
                              inputId = dataset_variable_menu_name,
                              choices = available_variables,
                              selected = selected_variable)
          } else {
            new_variable_column <-
              which(column_names == new_selected_variable)
            model <<-
              set_variable_column(model, dataset_index, new_variable_column)
            ASNAT_dprint("Set variable_column(selected_dataset) = %d\n",
                         variable_column(selected_dataset))

            # Update the map with new selected variable:

            the_map <<- draw_data_on_map()
            the_map <<- draw_timestamp_on_map()
            output$map <- renderLeaflet(the_map)

            clear_tables_and_plots()
          }
        }
      }
    }

    ASNAT_dprint("handle_dataset_menu_selections() returning.\n")
  }



  # Callback for dataset_x_menu:

  observeEvent(input$dataset_x_menu, {
    ASNAT_dprint("In dataset_x_menu callback.\n")
    handle_dataset_menu_selections(input$dataset_x_menu,
                                   input$dataset_x_variable_menu,
                                   "dataset_x_variable_menu")
  })



  # Callback for dataset_x_variable_menu:

  observeEvent(input$dataset_x_variable_menu, {
    ASNAT_dprint("In dataset_x_variable_menu callback.\n")
    handle_dataset_menu_selections(input$dataset_x_menu,
                                   input$dataset_x_variable_menu,
                                   "dataset_x_variable_menu")
  })



  # Callback for dataset_y_menu:

  observeEvent(input$dataset_y_menu, {
    ASNAT_dprint("In dataset_y_menu callback.\n")
    handle_dataset_menu_selections(input$dataset_y_menu,
                                   input$dataset_y_variable_menu,
                                   "dataset_y_variable_menu")
  })



  # Callback for dataset_y_variable_menu:

  observeEvent(input$dataset_y_variable_menu, {
    ASNAT_dprint("In dataset_y_variable_menu callback.\n")
    handle_dataset_menu_selections(input$dataset_y_menu,
                                   input$dataset_y_variable_menu,
                                   "dataset_y_variable_menu")
  })



  # Callback function (called by model) to show progress during web retrievals:

  retrieving_url_callback <- function(url, coverage, percent_done) {
    stopifnot(!is.null(url))
    stopifnot(class(url) == "character")
    stopifnot(nchar(url) > 0L)
    stopifnot(!is.null(coverage))
    stopifnot(class(coverage) == "character")
    stopifnot(nchar(coverage) > 0L)
    stopifnot(!is.null(percent_done))
    stopifnot(class(percent_done) == "numeric")

    retrieving_message <-
      sprintf("Retrieving %s data from webservice (%d%% done). Please wait...",
              coverage, trunc(percent_done))

    showNotification(retrieving_message,
                     duration = NULL, closeButton = FALSE,
                     id = "message_popup", type = "message")
  }



  # Callback for Retrieve data button:

  observeEvent(input$retrieve_data, {
    ASNAT_dprint("In retrieve_data callback.\n")

    set_retrieving_url_callback(model) <<- retrieving_url_callback

    showNotification("Retrieving data - please wait...",
                     duration = NULL, closeButton = FALSE,
                     id = "message_popup", type = "message")

    # Have the model retrieve and store each selected coverage:

    coverages <- input$coverage_menu
    urls <- character(0)

    timer <- ASNAT_start_timer()

    for (coverage in coverages) {
      ASNAT_dprint("coverage = %s\n", coverage)

      # If user selected menu separator line then skip it:

      if (grepl("[^A-Za-z0-9_.]", coverage)) {
        next
      }

      if (length(grep(fixed = TRUE, "PurpleAir", coverage)) > 0L &&
          !ASNAT_is_conforming_purple_air_key(input$purple_air_key)) {
        message_text <-
          "Skipping PurpleAir retrieval due to non-conforming PurpleAir Key."
        warning(message_text,
                call. = FALSE, immediate. = TRUE, noBreaks. = FALSE)
        output$message_area <- renderPrint({cat(message_text, sep = "\n")})
        next
      }

      model <<- retrieve_data(model, coverage)
      urls <- append(urls, retrieved_urls(model))
    }

    removeNotification("message_popup")

    count <- dataset_count(model)
    ASNAT_dprint("  dataset_count(model)) = %d\n", count)
    output$message_area <- renderPrint({cat(urls, sep = "\n")})

    # Draw data glyphs and legends and timestamp on the map:

    the_map <<- draw_data_on_map()
    the_map <<- draw_timestamp_on_map()
    ASNAT_dprint("calling renderLeaflet.\n")
    timer <- ASNAT_start_timer()
    output$map <- renderLeaflet(the_map)
    ASNAT_elapsed_timer("render map:", timer)

    update_dataset_x_y_selections()
    ASNAT_dprint("after update_dataset_x_y_selections()\n")
    ASNAT_elapsed_timer("retrieve_data callback:", timer)
    ASNAT_dprint("retrieve_data callback returning.\n")
  })



  # Callback for load_data_from_standard_file:

  observeEvent(input$load_data_from_standard_file, {
    ASNAT_dprint("In load_data_from_standard_file callback.\n")
    ok <- FALSE
    selected_file_data_frame <- input$load_data_from_standard_file

    if (length(selected_file_data_frame$datapath) == 1L) {
      selected_file_name <- selected_file_data_frame$datapath[[1L]]

      if (file.exists(selected_file_name)) {
        data_frame <- ASNAT_read_standard_file(selected_file_name)

        if (!is.null(data_frame)) {

          # Get short name of data_frame from short file name:

          short_file_name <- selected_file_data_frame$name[[1L]]
          len <- nchar(short_file_name)
          name <- ""

          for (index in 1L:len) {
            ch <- substr(short_file_name, index, index)

            if (ch %in% LETTERS || ch %in% letters) {
              name <- paste0(name, ch)
            } else {
              break
            }
          }

          if (!ASNAT_is_valid_dataset_name(name)) {
            name <- "fileset"
          }

          # Append data_frame and draw data:

          model <<- append_data_frame(model, data_frame, name)
          ok <- TRUE
          the_map <<- draw_data_on_map()
          the_map <<- draw_timestamp_on_map()
          output$map <- renderLeaflet(the_map)
          update_dataset_x_y_selections()
        }
      }
    }

    if (!ok) {
      showNotification("Failed to load standard file.",
                       duration = NULL, closeButton = TRUE, type = "message")
    }
  })



  # Callback for show_import_fileset:

  observeEvent(input$show_import_fileset, {
    ASNAT_dprint("In show_import_fileset callback.\n")
    showModal(
      modalDialog(
        fileInput("from_files", label = "Load Files:", multiple = TRUE,
                  accept = list(".csv")),

        shinyBS::bsTooltip("from_files",
                           "Load data from sensor instrument files.",
                           options = tooltip_options),

        numericInput("sensor_longitude", label = "Sensor longitude:",
                     width = "100px",
                     value = 0.0,
                     min = -180.0,
                     max = 180.0),

        shinyBS::bsTooltip("sensor_longitude",
                           paste0("Enter longitude of sensor (e.g., -74.05)."),
                           options = tooltip_options),

        numericInput("sensor_latitude", label = "Sensor latitude:",
                     width = "100px",
                     value = 0.0,
                     min = -90.0,
                     max = 90.0),

        shinyBS::bsTooltip("sensor_latitude",
                           paste0("Enter latitude of sensor (e.g., 40.72)."),
                           options = tooltip_options),

        textInput("fileset_name", "Dataset Name:", value = "MySensor"),

        shinyBS::bsTooltip("fileset_name",
                           paste0("Short simple name for dataset ",
                                  "(letters only, e.g., HomeRubber)."),
                           placement = "top",
                           options = tooltip_options),

        title = "Load Data From Files",
        size = "xl",
        fade = FALSE,
        footer = tagList(modalButton("Cancel"),
                         actionButton("load_files",
                                    label = "Process and Load Selected Files"))
      ))
  })



  # Files from last selection:

  selected_files_data_frame <- NULL

  # Callback for from_files:

  observeEvent(input$from_files, {
    ASNAT_dprint("In from_file callback.\n")
    selected_files_data_frame <<- input$from_files

    if (length(selected_files_data_frame$datapath) > 0L) {

      for (file in selected_files_data_frame$datapath) {
        ASNAT_filter_text_file(file)
      }

      first_file <- selected_files_data_frame$datapath[[1L]]
      first_line <- try(silent = TRUE, readLines(first_file, 1L))
      known_format <- FALSE

      if (startsWith(first_line, "UTCDateTime,mac_address,firmware_ver,")) {
        known_format <- TRUE # PurpleAir
      } else if (startsWith(first_line,
              "sensor:model,sensor:package,sensor:capability,sensor:units")) {
        #known_format <- TRUE # AirBeam
        known_format <- FALSE # AirBeam UNIMPLEMENTED.
        hide(id = "sensor_longitude")
        hide(id = "sensor_latitude")
      }

      if (!known_format) {
        showNotification("Unknown sensor file type.",
                         duration = NULL, closeButton = TRUE, type = "message")
        removeModal()
      }
    }
  })



  # Callback for load_files:

  observeEvent(input$load_files, {
    ASNAT_dprint("In load_files callback.\n")

    if (!is.null(selected_files_data_frame)) {
      aggregate <- "none"

      if (timestep_size(model) == "hours") {
        aggregate <- "hourly"
      } else {
        aggregate <- "daily"
      }

      showNotification("Processing files - please wait...",
                       duration = NULL, closeButton = FALSE,
                       id = "message_popup", type = "message")

      longitude <- input$sensor_longitude
      latitude <- input$sensor_latitude

      if (!(longitude >= -180.0 && longitude <= 180.0)) {
        longitude <- -74.05
      }

      if (!(latitude >= -90.0 && longitude <= 90.0)) {
        longitude <- 40.72
      }

      data_frame <-
        ASNAT_import(selected_files_data_frame, aggregate, longitude, latitude)

      removeNotification("message_popup")

      if (!is.null(data_frame)) {
        name <- input$fileset_name

        if (!ASNAT_is_valid_dataset_name(name)) {
          name <- "MySensor"
        }

        model <<- append_data_frame(model, data_frame, name)
        the_map <<- draw_data_on_map()
        the_map <<- draw_timestamp_on_map()
        output$map <- renderLeaflet(the_map)
        update_dataset_x_y_selections()
      } else {
        showNotification("Failed to load files.",
                         duration = NULL, closeButton = TRUE, type = "message")
      }

      selected_files_data_frame <- NULL
    }

    removeModal()
    ASNAT_dprint("load_files returning.\n")
  })



  update_map_timestep <- function(timestep) {
    stopifnot(isTruthy(timestep))
    stopifnot(timestep >= 0L)
    stopifnot(timestep < timesteps(model))
    timestep(model) <<- timestep

    # Draw data for timestep if there is any:

    if (dataset_count(model) > 0L) {
      the_map <<- draw_data_on_map()
    }

    the_map <<- draw_timestamp_on_map()
    timer <- ASNAT_start_timer()
    output$map <- renderLeaflet(the_map)
    ASNAT_elapsed_timer("render map:", timer)
  }



  # Callback for Legend Colormap menu:

  observeEvent(input$legend_colormap_menu, {
    is_valid_input <-
      shiny::isTruthy(input$legend_colormap_menu) &&
      !is.na(input$legend_colormap_menu) &&
      nchar(input$legend_colormap_menu[1L]) > 0L &&
      (input$legend_colormap_menu[1L] == "default" ||
      input$legend_colormap_menu[1L] == "AQI" ||
      input$legend_colormap_menu[1L] == "gray" ||
      input$legend_colormap_menu[1L] == "blue" ||
      input$legend_colormap_menu[1L] == "colorsafe" ||
      input$legend_colormap_menu[1L] == "viridis")

    if (is_valid_input) {
      legend_colormap(model) <<- input$legend_colormap_menu[1L]
    }

    # If there is data then redraw it on map:

    if (dataset_count(model) > 0L) {
      model_timestep <- timestep(model)
      update_map_timestep(model_timestep)
    }
  })



  # Callback for fancy labels checkbox:

  observeEvent(input$use_fancy_labels, {

    if (shiny::isTruthy(input$use_fancy_labels)) {
      use_fancy_labels(model) <<- TRUE
    } else {
      use_fancy_labels(model) <<- FALSE
    }

    # If there is data then redraw it on map with appropriate legend label:

    if (dataset_count(model) > 0L) {
      model_timestep <- timestep(model)
      update_map_timestep(model_timestep)
    }
  })



  # Callback for Timestep Slider:

  observeEvent(input$timestep_slider, {
    ASNAT_dprint("In timestep_slider callback with timestep = %d.\n",
                 as.integer(input$timestep_slider))

    if (isTruthy(input$timestep_slider)) {
      the_timestep <- as.integer(input$timestep_slider)

      if (the_timestep >= 0L && the_timestep < timesteps(model)) {
        update_map_timestep(the_timestep)
      }
    }
  })



  # Zoom map to location of loaded datasets and set start_date, days to
  # date range of loaded datasets:

  zoom_map_to_data <- function() {
    count <- dataset_count(model)

    if (count > 0L) {
      extent <- data_extent(model)
      west <- extent$west
      east <- extent$east
      south <- extent$south
      north <- extent$north
      the_start_date <- extent$start_date
      the_end_date <- extent$end_date

      total_days <- 1L + as.integer(the_end_date) - as.integer(the_start_date)

      if (total_days > 366L) {
        total_days <- 366L
        the_end_date <- the_start_date + 365L
      }

      # Set start date and days to the date range of loaded data:

      start_date(model) <<- the_start_date
      days(model) <<- total_days
      tomorrow <- Sys.Date() + 1L
      freezeReactiveValue(input, "start_date")
      updateDateInput(session = session, inputId = "start_date",
                      value = start_date(model),
                      min = "1970-01-01", max = tomorrow)
      freezeReactiveValue(input, "days")
      updateNumericInput(session = session, inputId = "days",
                         value = days(model))

      delta_degrees <- 0.001
      west <- west - delta_degrees
      east <- east + delta_degrees
      south <- south - delta_degrees
      north <- north + delta_degrees
      west_bound(model) <<- west
      east_bound(model) <<- east
      south_bound(model) <<- south
      north_bound(model) <<- north
      the_map <<- fitBounds(the_map, west, south , east, north)
      the_map <<- flyToBounds(the_map, west, south, east, north)
      longitude_center <- (west + east) * 0.5
      latitude_center <- (south + north) * 0.5

      # Compute zoom level from width (this should be done by fitBounds()!):

      width <- east - west
      # Start with zoom level 15 which makes the window width almost 5km.
      zoom_width <- 0.045
      zoom_level <- 15L

      while (width > zoom_width && zoom_level > 2L) {
        zoom_width <- zoom_width + zoom_width
        zoom_level <- zoom_level - 1L
      }

      the_map <<-
        setView(the_map, longitude_center, latitude_center, zoom = zoom_level)
      output$map <- renderLeaflet(the_map)
      update_purple_air_sites_menu()
    }
  }



  # Callback for Zoom To Data button:

  observeEvent(input$zoom_to_data, {
    ASNAT_dprint("In zoom_to_data callback\n")
    zoom_map_to_data()
  })



  # Helper function to create map image file:

  create_map_image_file <- function(map, width, height, file_name) {
    ASNAT_dprint("In create_map_image_file(%s)\n", file_name)
    timer <- ASNAT_start_timer()

    message <- paste0("Saving map image ", file_name, " - please wait...")
    showNotification(message,
                     duration = NULL, closeButton = FALSE,
                     id = "message_popup", type = "message")

    # FIX: How to make the saved image match that displayed here?
    # If no width/height arguments are passed to mapshot() then
    # the saved png image will always be 992 x 744.
    # If the main map is sized 992 x 744 then the png file will match the
    # leaflet view.
    # The 496 x 372 site_nighbor_map will be saved at 992 x 744 and match zoom
    # level but the detail of the png will be higher.
    # https://github.com/r-spatial/mapview/issues/487

     mapshot_result <-
       try(silent = TRUE, mapview::mapshot(map, file = file_name))

    #str(width)
    #str(height)
    # try(silent = TRUE,
    #     mapview::mapshot(map, file = file_name,
    #     vwidth = width, wheight = height))

    output$message_area <- renderPrint({cat(file_name, sep = "\n")})
    removeNotification("message_popup")
    ASNAT_elapsed_timer("create_map_image_file:", timer)
    return(file_name)
  }



  # Callback for Save Map Image button - when not remote-hosted:

  observeEvent(input$save_map_image, {
    check_set_reset_output_directory()
    model_output_directory <- output_directory(model)
    model_timestep <- timestep(model)
    file_name <-
      paste0(model_output_directory,
             sprintf("/map_image_%03d.png", model_timestep))
    create_map_image_file(the_map, the_map_width, the_map_height, file_name)
  })



  # Callback for Download Image button - when remote-hosted:

  output$download_map_image <- downloadHandler(
    filename = function() { sprintf("map_image_%03d.png", timestep(model)) },
    content = function(file) {
      check_set_reset_output_directory()
      model_output_directory <- output_directory(model)
      model_timestep <- timestep(model)
      file_name <-
        paste0(model_output_directory,
               sprintf("/map_image_%03d.png", model_timestep))
      image_file_name <-
        create_map_image_file(the_map, the_map_width, the_map_height, file_name)
      file.copy(from = image_file_name, to = file, overwrite = TRUE)
    },
    contentType = "image/png"
  )



  # Helper function to create movie file:

  create_movie_file <- function() {
    ASNAT_dprint("In create_movie_file().\n")
    check_set_reset_output_directory()
    timer <- ASNAT_start_timer()
    model_timesteps <- timesteps(model)
    model_timesteps_1 <- model_timesteps - 1L
    model_timestep <- timestep(model)
    model_output_directory <- output_directory(model)
    model_data_directory <- data_directory(model)
    model_app_directory <- app_directory(model)
    image_file_names <- vector(mode = "integer", length = model_timesteps)
    total_steps <- model_timesteps + 1L

    for (the_timestep in 0L:model_timesteps_1) {
      message <-
        sprintf("Saving map images (%0.0f%% done) - please wait...",
                100.0 * the_timestep / total_steps)
      showNotification(message, duration = NULL, closeButton = FALSE,
                       id = "message_popup", type = "message")
      update_map_timestep(the_timestep)
      output_image_file_name <-
        paste0(model_data_directory,
               sprintf("/map_image_%03d.png", the_timestep))
      output_image_file_name <-
        create_map_image_file(the_map, the_map_width, the_map_height,
                              output_image_file_name)
      image_file_names[[the_timestep + 1L]] <- output_image_file_name
    }

    timestep(model) <<- model_timestep

    # Create movie file from sequence of png images:

    output_movie_file_name <- paste0(model_output_directory, "/map_movie.mp4")

    if (file.exists(output_movie_file_name)) {
      unlink(output_movie_file_name)
    }

    command_quote <- "'"

    if (.Platform$OS.type == "windows") {
      command_quote <- '"'
    }

    platform <- ASNAT_platform()
    command <-
      sprintf(paste0("%s/%s/bin/ffmpeg -y -f image2 -r 3 -i ",
                     "%s%s/map_image_%%03d.png%s ",
                     "-vcodec mpeg4 -pix_fmt yuv420p -qscale:v 1 %s%s%s"),
                     model_app_directory, platform,
                     command_quote, model_data_directory, command_quote,
                     command_quote, output_movie_file_name, command_quote)
    cat(command, "\n")
    system(command)
    unlink(image_file_names)
    output$message_area <-
      renderPrint({cat(command, "\n", output_movie_file_name)})
    removeNotification("message_popup")
    ASNAT_elapsed_timer("create_movie_file:", timer)
    return(output_movie_file_name)
  }



  # Callback for Save Map Movie button:

  observeEvent(input$save_map_movie, {
    ASNAT_dprint("In save_map_movie callback.\n")
    create_movie_file()
  })



  # Callback for Download Movie button - when remote-hosted:

  output$download_map_movie <- downloadHandler(
    filename = "map_movie.mp4",
    content = function(file) {
      movie_file_name <- create_movie_file()
      output$message_area <-
        renderPrint({cat(movie_file_name, file, sep = "\n")})
      file.copy(from = movie_file_name, to = file, overwrite = TRUE)
    },
    contentType = "video/mp4"
  )



  # Check/set/reset output_directory:
  # Check if input$output_directory is valid:
  # if not valid then reset it
  # else if it does not exist then create it and update model
  # else it exists and update model.

  check_set_reset_output_directory <- function() {

    if (!ASNAT_is_remote_hosted) {

      # Check that the directory name is valid and does not contain spaces:

      is_valid_input <-
        shiny::isTruthy(input$output_directory) &&
        length(grep("[ ]", input$output_directory)) == 0L

      # If valid and non-existent then try to create it:

      if (is_valid_input) {

        if (!dir.exists(input$output_directory)) {
          dir.create(input$output_directory)
        }

        if (!dir.exists(input$output_directory)) {
          is_valid_input <- FALSE
        }
      }

      if (is_valid_input) {
        output_directory(model) <<- input$output_directory
      } else {

        # Reset GUI to model state value:

        model_output_directory <- output_directory(model)
        freezeReactiveValue(input, "output_directory")
        updateTextInput(session = session, inputId = "output_directory",
                          value = model_output_directory)
      }
    }

    ASNAT_dprint("output_directory(model) = %s\n", output_directory(model))
  }



  # Callback for output_format:

  observeEvent(input$output_format_menu, {
    is_valid_input <-
      shiny::isTruthy(input$output_format_menu) &&
      shiny::isTruthy(input$output_format_menu[1L]) &&
      (input$output_format_menu[1L] == "csv" ||
         input$output_format_menu[1L] == "tsv" ||
         input$output_format_menu[1L] == "json")

    if (!is_valid_input) {
      model_output_format <- output_format(model)
      freezeReactiveValue(input, "output_format")
      updateTextInput(session = session, inputId = "output_format",
                      value = model_output_format)
    } else {
      output_format(model) <<- input$output_format_menu[1L]
    }

    ASNAT_dprint("output_format(model) = %s\n", output_format(model))
  })



  # Callback for Save Data button - when not remote hosted:

  observeEvent(input$save_data, {
    check_set_reset_output_directory()

    if (dataset_count(model) > 0L) {
      model <<- save_datasets(model)
    }

    output$message_area <- renderPrint({cat(saved_files(model), sep = "\n")})
  })



  # Callback for Download Data button - when remote-hosted:

  output$download_data <- downloadHandler(
    filename = "ASNAT_data.zip",
    content = function(file) {

      if (dataset_count(model) > 0L) {
        check_set_reset_output_directory()
        model <<- save_datasets(model)
        model_saved_files <- saved_files(model)
        output$message_area <-
          renderPrint({cat(model_saved_files, file, sep = "\n")})
          #utils::zip(file, files = model_saved_files, flags = "-j")
        zip::zip(file, files = model_saved_files,
                 recurse = FALSE, include_directories = FALSE,
                 mode = "cherry-pick")
      }
    },
    contentType = "application/zip"
  )



  # Helper function: do we have selected datasets?

  have_datasets <- function() {
    have_x <-
      shiny::isTruthy(input$dataset_x_menu) &&
      shiny::isTruthy(input$dataset_x_menu[1L]) &&
      nchar(input$dataset_x_menu[1L]) > 0L &&
      shiny::isTruthy(input$dataset_x_variable_menu) &&
      shiny::isTruthy(input$dataset_x_variable_menu[1L]) &&
      nchar(input$dataset_x_variable_menu[1L]) > 0L

    have_y <-
      have_x &&
      shiny::isTruthy(input$dataset_y_menu) &&
      shiny::isTruthy(input$dataset_y_menu[1L]) &&
      nchar(input$dataset_y_menu[1L]) > 0L &&
      input$dataset_y_menu[1L] != "none" &&
      shiny::isTruthy(input$dataset_y_variable_menu) &&
      shiny::isTruthy(input$dataset_y_variable_menu[1L]) &&
      nchar(input$dataset_y_variable_menu[1L]) > 0L

    if (have_y) {
      different_dataset = input$dataset_y_menu[1L] != input$dataset_x_menu[1L]
      have_y <- different_dataset

      if (!different_dataset) {
        different_variable =
          input$dataset_y_variable_menu[1L] !=
          input$dataset_x_variable_menu[1L]
        have_y <- different_variable
      }
    }

    return(list(x = have_x, y = have_y))
  }



  # Possibly change variable column in a (shallow) copy of a returned dataset:

  set_dataset_variable <- function(dataset_name, dataset_variable) {
    coverages <- dataset_coverages(model)
    dataset_index <- which(coverages == dataset_name)
    dataset <- NULL

    if (dataset_index > 0L) {
      dataset <- dataset(model, dataset_index)
      data_frame <- data_frame(dataset)
      column_names <- colnames(data_frame)
      variable_column <- which(column_names == dataset_variable)

      if (variable_column(dataset) != variable_column) {
        variable_column(dataset) <- variable_column
      }
    }

    return(dataset)
  }



  # Helper function to get index of flag dataset or 0 if none:

  get_flag_dataset_index <- function() {
    result <- 0L
    is_valid_input <-
      shiny::isTruthy(input$flag_dataset_menu) &&
      !is.na(input$flag_dataset_menu) &&
      nchar(input$flag_dataset_menu) > 0L

    if (is_valid_input) {
      selection <- input$flag_dataset_menu[1L]
      have_datasets_result <- have_datasets()
      have_x <- have_datasets_result$x
      have_y <- have_datasets_result$y
      flag_dataset_name <- NULL

      if (input$flag_dataset_menu[1L] == "Dataset X") {

        if (have_x) {
          flag_dataset_name <- input$dataset_x_menu[1L]
        }
      } else if (have_y) {
        flag_dataset_name <- input$dataset_y_menu[1L]
      }

      if (!is.null(flag_dataset_name)) {
        coverages <- dataset_coverages(model)
        result <- which(coverages == flag_dataset_name)
      }
    }

    return(result)
  }



  # Helper function to show dataset content to flag:

  show_dataset_content_to_flag <- function() {
    dataset_index <- get_flag_dataset_index()

    if (dataset_index > 0L) {
      the_dataset <- dataset(model, dataset_index)
      data_frame <- data_frame(the_dataset)

      # BUG: Why are _state$length & _state$start NULL unless rows are clicked?
      rows_per_page <- input$dataset_content_to_flag_state$length
      first_displayed_row <- input$dataset_content_to_flag_state$start
      displayed_page = 1L

      if (!is.null(first_displayed_row)) {
        displayed_page <- displayed_page + first_displayed_row %/% rows_per_page
      }

      ASNAT_debug(str, input$dataset_content_to_flag_state)
      displayed_rows <- input$dataset_content_to_flag_rows_current

      # HACK: Must first render with default settings. Why?
      output$dataset_content_to_flag <- DT::renderDT(data_frame)

      if (length(displayed_rows) > 0L) {
        first_displayed_row <- displayed_rows[[1L]]
        displayed_page <- first_displayed_row %/% rows_per_page + 1L
        ASNAT_dprint("  recomputed displayed_page = %d\n", displayed_page)
        proxy <- DT::dataTableProxy("dataset_content_to_flag")
        DT::reloadData(proxy, resetPaging = FALSE)
        # BUG: resetPaging = FALSE does not work! Display resets to page 1.
        #DT::selectPage(proxy, displayed_page)
        # BUG: selectPage() does not work! Display resets to page 1.
        # UGLY HACK must use JS callback function to force staying on the page!
        # Note JavaScript numbers pages starting at 0.
        # Must wrap data_frame in another DT::datatable object with callback.
        displayed_page_1 <- displayed_page - 1L
        showPageJS <-
          paste0('function() {table.page(', displayed_page_1, ').draw(false);}')
        output$dataset_content_to_flag <-
          DT::renderDT(DT::datatable(data_frame, callback = JS(showPageJS)))
      }

      # https://laustep.github.io/stlahblog/posts/DTcallbacks.html#select-page-with-a-numeric-input
      # BUG: this does not work! Display resets to page 1.
      #output$dataset_content_to_flag <-
      #  DT::renderDT(data_frame, options = list(page = displayed_page))

    } else {
      output$dataset_content_to_flag <- DT::renderDT({NULL})
    }
  }



  # Callback for flag_dataset_menu:

  observeEvent(input$flag_dataset_menu, {
    ASNAT_dprint("In flag_dataset_menu callback.\n")
    show_dataset_content_to_flag()
  })



  # Helper function to set or clear 99 value of flagged column of selected rows:

  set_or_clear_99_flag_of_selected_rows <- function(flag) {
    stopifnot(flag == 0L || flag == 99L)
    selected_rows <- sort.int(input$dataset_content_to_flag_rows_selected)

    if (length(selected_rows) > 0L) {
      dataset_index <- get_flag_dataset_index()
      stopifnot(dataset_index > 0L)
      the_dataset <- dataset(model, dataset_index)
      data_frame <- data_frame(the_dataset)
      column_names <- colnames(data_frame)
      flagged_column <- ASNAT_flagged_column_index(column_names)
      stopifnot(flagged_column > 0L)
      flagged <- data_frame[selected_rows, flagged_column]

      if (flag == 99L) {
        flagged <-
          vapply(flagged, ASNAT_include_flag, c(""), 99L, USE.NAMES = FALSE)
      } else {
        flagged <-
          vapply(flagged, ASNAT_exclude_flag, c(""), 99L, USE.NAMES = FALSE)
      }

      data_frame[selected_rows, flagged_column] <- flagged
      flagged <- data_frame[[flagged_column]]
      model <<- replace_flagged_column(model, dataset_index, flagged)
      show_dataset_content_to_flag()
    }
  }



  # Callback for exclude_99_flagged:

  observeEvent(input$exclude_99_flagged, {
    ASNAT_dprint("In exclude_99_flagged callback.\n")
    set_or_clear_99_flag_of_selected_rows(0L)
  })



  # Callback for include_99_flagged:

  observeEvent(input$include_99_flagged, {
    ASNAT_dprint("In include_99_flagged callback.\n")
    set_or_clear_99_flag_of_selected_rows(99L)
  })




  # Callback for load_flag_conditions:

  observeEvent(input$load_flag_conditions, {
    ASNAT_dprint("In load_flag_conditions callback.\n")
    ok <- FALSE
    selected_file_data_frame <- input$load_flag_conditions

    if (length(selected_file_data_frame$datapath) == 1L) {
      selected_file_name <- selected_file_data_frame$datapath[[1L]]

      if (file.exists(selected_file_name)) {
        flag_conditions <- try(silent = TRUE, readLines(selected_file_name))

        if (class(flag_conditions) == "character" &&
            length(flag_conditions) > 0L) {
          updateTextAreaInput(session = session, inputId = "flag_conditions",
                              value = paste(collapse = "\n", flag_conditions))
          ok <- TRUE
        }
      }
    }

    if (!ok) {
      showNotification("Failed to load flags file.",
                       duration = NULL, closeButton = TRUE, type = "message")
    }
  })



  # Callback for Apply Flagging button:

  observeEvent(input$apply_flagging, {

    if (shiny::isTruthy(input$flag_dataset_menu) &&
        nchar(input$flag_dataset_menu) > 0L &&
        shiny::isTruthy(input$flag_conditions) &&
        length(input$flag_conditions) > 0L) {
      have_datasets_result <- have_datasets()
      have_x <- have_datasets_result$x
      have_y <- have_datasets_result$y
      flag_dataset_name <- NULL

      if (input$flag_dataset_menu == "Dataset X") {

        if (have_x) {
          flag_dataset_name <- input$dataset_x_menu[1L]
        }
      } else if (have_y) {
        flag_dataset_name <- input$dataset_y_menu[1L]
      }

      if (!is.null(flag_dataset_name)) {
        coverages <- dataset_coverages(model)
        dataset_index <- which(coverages == flag_dataset_name)

        if (dataset_index > 0L) {
          showNotification("Applying flag conditions...",
                            duration = NULL, closeButton = FALSE,
                            id = "message_popup", type = "message")
          flag_conditions <- unlist(strsplit(input$flag_conditions, "\n"))
          model <<-
            apply_flag_conditions(model, dataset_index, flag_conditions)
          show_dataset_content_to_flag()
          removeNotification("message_popup")
        }
      }
    }
  })



  # Callback for Save Flag Conditions button - when not remote hosted:

  observeEvent(input$save_flag_conditions, {
    have_flag_conditions <-
      shiny::isTruthy(input$flag_conditions) &&
      nchar(input$flag_conditions) > 0L

    if (have_flag_conditions) {
      check_set_reset_output_directory()
      flags_file_name <- paste0(output_directory(model), "/flags.txt")
      cat(append = TRUE, sep = "\n", file = flags_file_name,
          input$flag_conditions)
      output$message_area <- renderPrint({flags_file_name})
    }
  })



  # Callback for Download Flag Conditions button - when remote-hosted:

  output$download_flag_conditions <- downloadHandler(
    filename = "flags.txt",
    content = function(file) {
      have_flag_conditions <-
        shiny::isTruthy(input$flag_conditions) &&
        nchar(input$flag_conditions) > 0L

      if (have_flag_conditions) {
        check_set_reset_output_directory()
        flags_file_name <- paste0(output_directory(model), "/flags.txt")
        cat(append = TRUE, sep = "\n", file = flags_file_name,
            input$flag_conditions)
        output$message_area <- renderPrint({flags_file_name})
        file.copy(from = flags_file_name, to = file, overwrite = TRUE)
      }
    },
    contentType = "text/plain"
  )



  # Callback for Apply Difference button:

  observeEvent(input$apply_difference, {
    apply_max_neighbor_value_diff(model) <<- input$apply_difference
  })



  # Callback for Maximum Neighbor Value Difference:

  observeEvent(input$maximum_neighbor_value_difference, {
    is_valid_input <-
      shiny::isTruthy(input$maximum_neighbor_value_difference) &&
      !is.na(input$maximum_neighbor_value_difference) &&
      input$maximum_neighbor_value_difference >= 0.0 &&
      input$maximum_neighbor_value_difference <= 100.0

    if (!is_valid_input) {
      model_value <- maximum_neighbor_value_difference(model)
      freezeReactiveValue(input, "maximum_neighbor_value_difference")
      updateNumericInput(session = session,
                         inputId = "maximum_neighbor_value_difference",
                         value = model_value)
    } else {
      new_value <- input$maximum_neighbor_value_difference
      max_neighbor_value_diff(model) <<- new_value
    }
  })



  # Callback for Apply Percent Difference button:

  observeEvent(input$apply_percent_difference, {
    apply_max_neighbor_val_pdiff(model) <<- input$apply_percent_difference
  })



  # Callback for Maximum Neighbor Value Percent Difference:

  observeEvent(input$maximum_neighbor_value_percent_difference, {
    is_valid_input <-
      shiny::isTruthy(input$maximum_neighbor_value_percent_difference) &&
      !is.na(input$maximum_neighbor_value_percent_difference) &&
      input$maximum_neighbor_value_percent_difference >= 0.0 &&
      input$maximum_neighbor_value_percent_difference <= 100.0

    if (!is_valid_input) {
      model_value <- maximum_neighbor_value_percent_difference(model)
      freezeReactiveValue(input, "maximum_neighbor_value_percent_difference")
      updateNumericInput(session = session,
                         inputId = "maximum_neighbor_value_percent_difference",
                         value = model_value)
    } else {
      new_value <- input$maximum_neighbor_value_percent_difference
      max_neighbor_value_pdiff(model) <<- new_value
    }
  })



  # Callback for Apply R-Squared button:

  observeEvent(input$apply_r_squared, {
    apply_min_neighbor_value_r2(model) <<- input$apply_r_squared
  })



  # Callback for Minimum Neighbor Value R-Squared:

  observeEvent(input$minimum_neighbor_value_r_squared, {
    is_valid_input <-
      shiny::isTruthy(input$minimum_neighbor_value_r_squared) &&
      !is.na(input$minimum_neighbor_value_r_squared) &&
      input$minimum_neighbor_value_r_squared >= 0.0 &&
      input$minimum_neighbor_value_r_squared <= 1.0

    if (!is_valid_input) {
      model_value <- minimum_neighbor_value_r_squared(model)
      freezeReactiveValue(input, "minimum_neighbor_value_r_squared")
      updateNumericInput(session = session,
                         inputId = "minimum_neighbor_value_r_squared",
                         value = model_value)
    } else {
      new_value <- input$minimum_neighbor_value_r_squared
      min_neighbor_value_r2(model) <<- new_value
    }
  })



  summarizing <- FALSE

  # Summarize and compare Datasets X and Y and show computed tables:

  summarize_and_compare_datasets_x_y <- function() {
    ASNAT_dprint("summarize_and_compare_datasets_x_y called.\n")
    timer <- ASNAT_start_timer()

    ASNAT_dprint("In handle_summarize(), summarizing = %d\n",
                 as.integer(summarizing))

    ASNAT_debug(str, input$dataset_x_menu)
    ASNAT_debug(str, input$dataset_x_menu[1L])

    have <- have_datasets()
    have_x <- have$x
    have_y <- have$y

    if (summarizing) {
      return(NULL)
    }

    model <<- delete_dataset_summaries(model)
    clear_tables_and_plots()

    if (!have_x) {
      return(NULL)
    }

    ASNAT_dprint("  have_x = %d, have_y = %d\n",
                 as.integer(have_x), as.integer(have_y))
    summarizing <<- TRUE
    ASNAT_dprint("  set summarizing = %d\n", as.integer(summarizing))

    dataset_x_name <- input$dataset_x_menu[1L]
    dataset_x_variable <- input$dataset_x_variable_menu[1L]
    dataset_y_name <- NULL
    dataset_y_variable <- NULL

    if (have_y) {
      dataset_y_name <- input$dataset_y_menu[1L]
      dataset_y_variable <- input$dataset_y_variable_menu[1L]
    }

    showNotification("Summarizing and comparing data...",
                     duration = NULL, closeButton = FALSE,
                     id = "message_popup", type = "message")

    model <<- summarize_datasets(model, dataset_x_name, dataset_x_variable,
                                 dataset_y_name, dataset_y_variable)

    if (ok(model)) {
      summary_data_frame_x <- summary_x_data_frame(model)
      summary_data_frame_y <- NULL

      if (have_y) {
        summary_data_frame_y <- summary_y_data_frame(model)
      }

      ASNAT_dprint("summary_data_frame_x:\n")
      ASNAT_debug(str, summary_data_frame_x)
      title_x <- summary_x_title(model)
      subtitle_x <- summary_x_subtitle(model)
      caption_x <-
        as.character(tags$div(tags$h4(style = "color: black", title_x),
                              tags$h5(style = "color: black", subtitle_x)))
      caption_x <- fancy_label(caption_x)
      column_names <- colnames(summary_data_frame_x)
      fancy_column_names <-
        vapply(column_names, fancy_label, c(""), USE.NAMES = FALSE)
      colnames(summary_data_frame_x) <- fancy_column_names

      output$table1 <- renderTable(summary_data_frame_x,
                                   caption = caption_x,
                                   caption.placement = "top")

      if (!is.null(summary_data_frame_y)) {
        ASNAT_dprint("summary_data_frame_y:\n")
        ASNAT_debug(str, summary_data_frame_y)
        title_y <- summary_y_title(model)
        subtitle_y <- summary_y_subtitle(model)
        caption_y <-
          as.character(tags$div(tags$h4(style = "color: black", title_y),
                                tags$h5(style = "color: black", subtitle_y)))
        caption_y <- fancy_label(caption_y)
        column_names <- colnames(summary_data_frame_y)
        fancy_column_names <-
          vapply(column_names, fancy_label, c(""), USE.NAMES = FALSE)
        colnames(summary_data_frame_y) <- fancy_column_names

        output$table2 <- renderTable(summary_data_frame_y,
                                     caption = caption_y,
                                     caption.placement = "top")

        model <<- compare_datasets(model, dataset_x_name, dataset_x_variable,
                                   dataset_y_name, dataset_y_variable)

        the_comparison_data_frame <- comparison_data_frame(model)

        if (nrow(the_comparison_data_frame) > 0L) {
          ASNAT_dprint("the_comparison_data_frame:\n")
          ASNAT_debug(str, the_comparison_data_frame)
          title <- comparison_title(model)
          subtitle <- comparison_subtitle(model)

          caption <-
            as.character(tags$div(tags$h4(style = "color: black", title),
                                  tags$h5(style = "color: black", subtitle)))
          caption <- fancy_label(caption)
          column_names <- colnames(the_comparison_data_frame)
          fancy_column_names <-
            vapply(column_names, fancy_label, c(""), USE.NAMES = FALSE)
          colnames(the_comparison_data_frame) <- fancy_column_names

          output$table3 <-
            renderTable(the_comparison_data_frame,
                        caption = caption, caption.placement = "top")

          the_comparison_r2_data_frame <- comparison_r2_data_frame(model)

          if (nrow(the_comparison_r2_data_frame) > 0L) {
            ASNAT_dprint("the_comparison_r2_data_frame:\n")
            ASNAT_debug(str, the_comparison_r2_data_frame)
            title <- comparison_r2_title(model)
            subtitle <- comparison_r2_subtitle(model)
            caption <-
              as.character(tags$div(tags$h4(style = "color: black", title),
                                    tags$h5(style = "color: black", subtitle)))
            caption <- fancy_label(caption)
            column_names <- colnames(the_comparison_r2_data_frame)
            fancy_column_names <-
              vapply(column_names, fancy_label, c(""), USE.NAMES = FALSE)
            colnames(the_comparison_r2_data_frame) <- fancy_column_names

            output$table4 <-
              renderTable(the_comparison_r2_data_frame, digits = 4,
                          caption = caption, caption.placement = "top")
          }
        }
      }
    }

    show_dataset_content_to_flag()
    removeNotification("message_popup")

    if (nrow(summary_x_data_frame(model)) == 0L) {
      message_text <-
        paste0("There are no neighboring points within ",
               maximum_neighbor_distance(model), " meters.\n")
      showNotification(message_text,
                       duration = 5, closeButton = TRUE,
                       id = "message_popup2", type = "warning")
    }

    summarizing <<- FALSE
    ASNAT_dprint("  reset summarizing = %d\n", as.integer(summarizing))
    ASNAT_elapsed_timer("summarize_and_compare_datasets_x_y:", timer)
  }



  # Callback for Interactive (color) Plots checkbox
  # (also uses fancy labels in interactive plots):

  observeEvent(input$use_interactive_plots, {

    if (shiny::isTruthy(input$use_interactive_plots)) {
      use_interactive_plots(model) <<- TRUE
    } else {
      use_interactive_plots(model) <<- FALSE
    }

    # If there is data then redraw it on map with appropriate legend label:

    if (dataset_count(model) > 0L) {
      model_timestep <- timestep(model)
      update_map_timestep(model_timestep)
    }
  })



  # Helper for fancy legend labels:

  fancy_legend_label <- function(label) {
    stopifnot(nchar(label) > 0L)
    result <- label

    if (use_fancy_labels(model)) {
      result <- ASNAT_fancy_label(result)
    }

    return(result)
  }



  # Helper for fancy labels:

  fancy_label <- function(label) {
    stopifnot(nchar(label) > 0L)
    result <- label

    if (use_interactive_plots(model)) {
      result <- ASNAT_fancy_label(result)
    }

    return(result)
  }



  # Callback for Summarize and Compare X & Y button:

  observeEvent(input$summarize, {
    summarize_and_compare_datasets_x_y()
    update_neighbors_menu()
  })



  ############################# Boxplot functions #############################

  flagged_point_color <- "gray"
  #timeseries_pch <- "*"
  timeseries_pch <- "o"
  saved_plot_files <- vector()


  # Helper to draw boxplot of a data.frame:
  # https://stackoverflow.com/questions/27276994/outputting-shiny-non-ggplot-plot-to-pdf#27381557

  draw_boxplot <-
  function(data_frame, main_title, x_label, y_label, interactive, file_name) {
    stopifnot(!is.null(data_frame))
    stopifnot(class(data_frame) == "data.frame")
    stopifnot(ncol(data_frame) >= 2L)
    stopifnot(nrow(data_frame) > 0L)
    stopifnot(!is.null(colnames(data_frame)))
    stopifnot(nchar(main_title) > 0L)
    stopifnot(nchar(x_label) > 0L)
    stopifnot(nchar(y_label) > 0L)
    stopifnot(interactive == TRUE || interactive == FALSE)
    ASNAT_dprint("In draw_boxplot(%s)\n", main_title)
    result <- NULL

    if (!is.null(file_name)) {
      ASNAT_dprint("In draw_boxplot() calling pdf(%s)\n", file_name)
      pdf(file_name, width = the_pdf_width, height = the_pdf_height)
      result <- boxplot(measure ~ site_id, data_frame,
                        main = main_title,
                        #xlab = x_label,
                        xlab = "",
                        ylab = y_label,
                        las = 2L)
      dev.off()
    } else {

      if (!interactive) {
        result <- renderPlot({
          boxplot(measure ~ site_id, data_frame,
                  main = main_title,
                  #xlab = x_label,
                  xlab = "",
                  ylab = y_label,
                  las = 2L)
        })
      } else {
        result <- renderPlotly({
          plotly::plot_ly(data_frame,
                          x = ~as.character(site_id), y = ~measure,
                          type = "box",
                          # FIX: Set color to black or gray.
                          colors = "gray",
                          marker = list(color = "gray"),
                          line = list(color = "gray")) %>%
          plotly::layout(title = main_title,
                         xaxis = list(title = x_label),
                         yaxis = list(title = y_label))
        })
      }
    }

    return(result)
  }



  # Draw dataset summary box plot of selected dataset (possibly filtered ids)
  # or, if a single site_id is specified with neighbor ids then plot single site
  # and its neighbors:

  draw_dataset_boxplot <-
  function(dataset_name, dataset_variable, filter_ids,
           neighbor_dataset_name, neighbor_dataset_variable,
           neighbor_ids, neighbor_distance, save_to_file) {

    ASNAT_dprint("In draw_dataset_boxplot(%s)\n", dataset_name)

    # Don't save interactive plots as PDF files.

    interactive <- use_interactive_plots(model) && !save_to_file

    # Get the data frame subsetted by filter_ids:

    the_dataset <- set_dataset_variable(dataset_name, dataset_variable)
    the_data_frame <- data_frame(the_dataset)
    subset_data_frame <- the_data_frame
    column_names <- colnames(the_data_frame)
    site_column <- ASNAT_site_column_index(column_names)
    is_single_site <- length(filter_ids) == 1L
    single_site_id <- 0L

    # Filter the data frame by filter_ids:

    if (!is.null(filter_ids)) {
      sites <- filter_ids
      sites <- sort.int(sites)
      sites <- unique(sites)
      is_single_site <- length(sites) == 1L
      matched_rows <- which(the_data_frame[[site_column]] %in% sites)
      stopifnot(length(matched_rows) > 0L)

      if (is_single_site) {
        single_site_id <- sites[[1L]]
      }

      subset_data_frame <- the_data_frame[matched_rows, ]
    }

    if (nrow(subset_data_frame) < 1L) return(NULL)

    # Filter the neighbor data frame by neighbor_ids:

    neighbor_dataset <- NULL
    neighbor_data_frame <- NULL
    subset_neighbor_data_frame <- NULL
    neighbor_column_names <- NULL
    neighbor_site_column <- 0L

    if (is_single_site &&
        !is.null(neighbor_dataset_name) &&
        !is.null(neighbor_dataset_variable) &&
        !is.null(neighbor_ids)) {
      neighbor_dataset <-
        set_dataset_variable(neighbor_dataset_name, neighbor_dataset_variable)
      neighbor_data_frame <- data_frame(neighbor_dataset)
      neighbor_column_names <- colnames(neighbor_data_frame)
      neighbor_site_column <- ASNAT_site_column_index(neighbor_column_names)
      sites <- neighbor_ids
      sites <- sort.int(sites)
      sites <- unique(sites)
      matched_rows <-
        which(neighbor_data_frame[[neighbor_site_column]] %in% sites)
      stopifnot(length(matched_rows) > 0L)
      subset_neighbor_data_frame <- neighbor_data_frame[matched_rows, ]
    }

    # Create main title with date range, bbox, etc.
    # and y-axis label with measure and units.

    units <- variable_units(the_dataset)
    source <- coverage_source(the_dataset)
    source_variable <- source_variable(the_dataset)
    fancy_source_variable <- source_variable
    the_variable <- variable_name(the_dataset)
    fancy_variable <- the_variable

    if (interactive) {
      fancy_variable <- fancy_label(the_variable)
      units <- fancy_label(units)
      fancy_source_variable <-
        paste0(coverage_source(the_dataset), ".",
               fancy_label(variable_name(the_dataset)))
    }

    # Get date-time range:

    first_model_timestamp <- first_timestamp(model)
    last_model_timestamp <- last_timestamp(model)
    model_timestep_size <- timestep_size(model)
    date_range <- substr(first_model_timestamp, 1L, 10L)

    if (days(model) > 1L) {
      date_range <-
        paste0(date_range, " - ", substr(last_model_timestamp, 1L, 10L))
    }

    timestamp_length <- 13L

    if (model_timestep_size == "days") {
      timestamp_length <- 10L
    }

    first_model_timestamp <-
      substr(first_model_timestamp, 1L , timestamp_length)

    # Get bounds of viewing area:

    west <- west_bound(the_dataset)
    east <- east_bound(the_dataset)
    south <- south_bound(the_dataset)
    north <- north_bound(the_dataset)

    main_title <-
      sprintf("Dataset Summary: %s\n%s (%0.4f, %0.4f) - (%0.4f, %0.4f)",
              ifelse(interactive, fancy_source_variable, source_variable),
              date_range, west, east, south, north)

    y_label <-
      paste0(ifelse(interactive, fancy_variable, the_variable),
             "(", units, ")")

    # If plotting a single site with its neighbors then recreate main title:

    if (!is.null(subset_neighbor_data_frame)) {
      longitudes <- subset_data_frame[[2L]]
      latitudes <- subset_data_frame[[3L]]
      longitude <- longitudes[[1L]]
      latitude <- latitudes[[1L]]
      neighbor_source_variable <- source_variable(neighbor_dataset)
      neighbor_variable <- variable_name(neighbor_dataset)
      fancy_neighbor_source_variable <- neighbor_source_variable

      if (interactive) {
        fancy_neighbor_source_variable <-
          paste0(coverage_source(neighbor_dataset), ".",
                 fancy_label(neighbor_variable))
      }

      main_title <-
        sprintf("%s Site %d Neighbors (<= %dm) Summary:\n%s vs %s\n%s (%0.4f, %0.4f)",
                source, single_site_id, neighbor_distance,
                ifelse(interactive, fancy_source_variable, source_variable),
                ifelse(interactive, fancy_neighbor_source_variable, neighbor_source_variable),
                date_range, longitude, latitude)
    }

    # Plotted data frame will have just two columns: site and measure:

    measure_column <- variable_column(the_dataset)
    subset_data_frame <- subset_data_frame[, c(site_column, measure_column)]
    colnames(subset_data_frame) <- c("site_id", "measure")

    if (is.null(neighbor_dataset)) {

      # Add first/left boxplot as a summary of all (filtered) site measures,
      # prepend rows with id = 0 and all (filtered) measures:

      filtered_row_count <- nrow(subset_data_frame)
      ids0 <- rep(0L, filtered_row_count)
      filtered_measures <- subset_data_frame[[2L]]
      extra_data_frame <- data.frame(site_id = ids0, measure = filtered_measures)
      subset_data_frame <- rbind(extra_data_frame, subset_data_frame)
    } else {

      # Append rows with neighbor site_ids and measures:

      neighbor_measure_column <- variable_column(neighbor_dataset)
      subset_neighbor_data_frame <-
        subset_neighbor_data_frame[, c(neighbor_site_column, neighbor_measure_column)]
      neighbor_measures <- subset_neighbor_data_frame[[2L]]
      neighbor_sites <- subset_neighbor_data_frame[[1L]]
      neighbors_data_frame <-
        data.frame(site_id = neighbor_sites, measure = neighbor_measures)
      subset_data_frame <- rbind(subset_data_frame, neighbors_data_frame)
    }

    ASNAT_dprint("Rendering boxplot with %s\n", source_variable)
    ASNAT_debug(str, subset_data_frame)

    x_label <- ifelse(is_single_site, "Site_Id", "Site_Id (0 = all)")
    pdf_file <- NULL

    if (save_to_file) {
      directory <- output_directory(model)
      site_string <- ""

      if (is_single_site) {
        site_string <-
          paste0("_site_", single_site_id, "_neighbors_",
                 neighbor_source_variable)
      }

      pdf_file <-
        paste0(directory, "/",
               gsub(fixed = TRUE, ".", "_", source_variable),
               site_string,
               "_boxplot.pdf")
      saved_plot_files <<- append(saved_plot_files, pdf_file)
    }

    result <-
      draw_boxplot(subset_data_frame, main_title, x_label, y_label,
                   interactive, pdf_file)
  }



  ########################## Timeseries Plot functions ########################

  # Helper to make basic timeseries plot:
  # The first call (with result NULL) creates the boxplot with the first
  # set of points. Subsequent calls add points and lines to the boxplot result.
  # https://www.statology.org/how-to-plot-multiple-lines-data-series-in-one-chart-in-r/

  make_basic_timeseries_plot <-
  function(x_values, y_values,
           x_minimum, x_maximum, y_minimum, y_maximum,
           symbol, main_title, x_label, y_label, point_colors,
           has_flagged_points, line_label, result) {

    if (is.null(result)) {
      # HACK: Unlike interactive plots, assigning to result from plot(),
      # points(), lines() makes the plot not display right!
      #result <-
      result <- TRUE
        plot(x = x_values, y = y_values,
             xlim = c(x_minimum, x_maximum), ylim = c(y_minimum, y_maximum),
             type = "o", pch = symbol, lty = 3L,
             main = main_title, xlab = x_label, ylab = y_label, las = 1L,
             # xaxp = c(x_minimum, x_maximum, 20L),
             col = point_colors)

      # If the plot includes flagged data points then include a text legend
      # that explains that gray points indicate flagged data points.

      if (has_flagged_points) {
        flagged_label <- "o = flagged"
        flagged_point_color <- "gray"
        flagged_label_x <- x_minimum
        flagged_label_y <- y_minimum + (y_maximum - y_minimum) * 0.9
        #result <- result %>%
          text(labels = flagged_label,
               x = flagged_label_x, y = flagged_label_y, adj = c(0, 0),
               col = flagged_point_color)
      }
    } else {
      #result <- result %>%
        points(x = x_values, y = y_values, pch = symbol, col = point_colors)

      #result <- result %>%
        lines(x = x_values, y = y_values, lty = 3L)
    }

    return(result)
  }



  # Helper to make interactive timeseries plot:
  # The first call (with result NULL) creates the boxplot with the first
  # set of points. Subsequent calls add points and lines to the boxplot result.

  make_interactive_timeseries_plot <-
  function(x_values, y_values,
           x_minimum, x_maximum, y_minimum, y_maximum,
           symbol, main_title, x_label, y_label, point_colors,
           has_flagged_points, line_label, result) {

    if (is.null(result)) {

      # FIX: How can the point/line style of flagged points be shown?

      annotations_list <- NULL

      if (has_flagged_points) {
        flagged_label <- "o = flagged"
        flagged_point_color <- "gray"
        flagged_label_x <- x_minimum
        flagged_label_y <- y_minimum + (y_maximum - y_minimum) * 0.9
        annotations_list <- list(showarrow = FALSE,
                                 text = flagged_label,
                                 x = flagged_label_x,
                                 y = flagged_label_y,
                                 color = flagged_point_color)
      }

      result <-
        plotly::plot_ly(x = x_values, y = y_values,
                        type = "scatter", mode = "lines+markers",
                        line = list(width = 1L, linetype = "dash"),
                        marker = list(size = 4L,
                                      symbols = symbol,
                                      fillcolor = 'none',
                                      line = list(color = point_colors,
                                                  width = 1L)),
                      name = line_label) %>%
        plotly::layout(title = main_title,
                       yaxis = list(title = y_label),
                       xaxis = list(title = x_label),
                       annotations = annotations_list)
    } else {
      result <- result %>%
        plotly::add_trace(x = x_values, y = y_values,
                         type = "scatter", mode = "lines+markers",
                         line = list(width = 1L, linetype = "dash"),
                         marker = list(size = 4L,
                                       symbols = symbol,
                                       color = "none",
                                       line = list(color = point_colors,
                                                   width = 1L)),
                         name = line_label)
    }

    return(result)
  }



  # Helper for looping through each site's measures for timeseries plot.

  make_timeseries_plot_helper <-
  function(data_frame,
           timestamp_column, site_column, measure_column, flagged_column,
           timestamp_format,
           time_0, time_last, minimum, maximum,
           interactive, main_title, x_label, y_label,
           point_colors, has_flagged_points,
           plotter, result) {

    stopifnot(!is.null(data_frame))
    stopifnot(class(data_frame) == "data.frame")
    stopifnot(ncol(data_frame) >= 4L)
    stopifnot(nrow(data_frame) > 0L)
    stopifnot(!is.null(colnames(data_frame)))
    stopifnot(timestamp_column >= 1L && timestamp_column <= ncol(data_frame))
    stopifnot(site_column >= 1L && site_column <= ncol(data_frame))
    stopifnot(measure_column >= 1L && measure_column <= ncol(data_frame))
    stopifnot(flagged_column >= 1L && flagged_column <= ncol(data_frame))
    stopifnot(nchar(timestamp_format) > 0L)
    stopifnot(time_0 <= time_last)
    stopifnot(minimum <= maximum)
    stopifnot(interactive == TRUE || interactive == FALSE)
    stopifnot(nchar(main_title) > 0L)
    stopifnot(nchar(x_label) > 0L)
    stopifnot(nchar(y_label) > 0L)
    stopifnot(!is.null(point_colors))
    stopifnot(has_flagged_points == TRUE || has_flagged_points == FALSE)
    stopifnot(!is.null(plotter))

    sites <- data_frame[[site_column]]
    sites <- sort.int(sites)
    sites <- unique(sites)

    for (site in sites) {
      matched_rows <- which(data_frame[[site_column]] == site)
      subset_data_frame <- data_frame[matched_rows, ]
      measures <- subset_data_frame[[measure_column]]
      flagged <- subset_data_frame[[flagged_column]]
      point_colors <- ifelse(flagged == "0", "black", flagged_point_color)
      timestamps <- subset_data_frame[[timestamp_column]]
      timestamp_labels <-
        as.POSIXct(timestamps, timestamp_format, tz = "UTC")

      # http://www.sthda.com/english/wiki/r-plot-pch-symbols-the-different-point-shapes-available-in-r

      symbol <- NULL

      if (!interactive) {
        symbol <- ifelse(is.null(result), 0L, 1L)
      } else{
        symbol <- ifelse(is.null(result), "circle-open", "o")
      }

      result <-
        plotter(timestamp_labels, measures,
                time_0, time_last, minimum, maximum,
                symbol, main_title, x_label, y_label,
                point_colors, has_flagged_points, site, result)
    }

    return(result)
  }



  # Helper to draw timeseries plot of data_frame and neighbor_data_frame.

  draw_timeseries_plot <-
  function(data_frame, timestamp_column, site_column, measure_column,
           flagged_column,
           neighbor_data_frame, neighbor_timestamp_column,
           neighbor_site_column, neighbor_measure_column,
           neighbor_flagged_column,
           timestamp_format, time_0, time_last, minimum, maximum,
           interactive, main_title, x_label, y_label, file_name) {

    stopifnot(!is.null(data_frame))
    stopifnot(class(data_frame) == "data.frame")
    stopifnot(ncol(data_frame) >= 4L)
    stopifnot(nrow(data_frame) > 0L)
    stopifnot(!is.null(colnames(data_frame)))
    stopifnot(timestamp_column >= 1L && timestamp_column <= ncol(data_frame))
    stopifnot(site_column >= 1L && site_column <= ncol(data_frame))
    stopifnot(measure_column >= 1L && measure_column <= ncol(data_frame))
    stopifnot(flagged_column >= 1L && flagged_column <= ncol(data_frame))
    stopifnot(is.null(neighbor_data_frame) ||
              class(neighbor_data_frame) == "data.frame")
    stopifnot(is.null(neighbor_data_frame) || ncol(neighbor_data_frame) >= 4L)
    stopifnot(is.null(neighbor_data_frame) || nrow(neighbor_data_frame) > 0L)
    stopifnot(is.null(neighbor_data_frame) ||
              !is.null(colnames(neighbor_data_frame)))
    stopifnot(is.null(neighbor_data_frame) ||
              (neighbor_timestamp_column >= 1L &&
               neighbor_timestamp_column <= ncol(neighbor_data_frame)))
    stopifnot(is.null(neighbor_data_frame) ||
              (neighbor_site_column >= 1L &&
               neighbor_site_column <= ncol(neighbor_data_frame)))
    stopifnot(is.null(neighbor_data_frame) ||
              (neighbor_measure_column >= 1L &&
               neighbor_measure_column <= ncol(neighbor_data_frame)))
    stopifnot(is.null(neighbor_data_frame) ||
              (neighbor_flagged_column >= 1L &&
               neighbor_flagged_column <= ncol(neighbor_data_frame)))
    stopifnot(nchar(timestamp_format) > 0L)
    stopifnot(time_0 <= time_last)
    stopifnot(minimum <= maximum)
    stopifnot(interactive == TRUE || interactive == FALSE)
    stopifnot(nchar(main_title) > 0L)
    stopifnot(nchar(x_label) > 0L)
    stopifnot(nchar(y_label) > 0L)

    ASNAT_dprint("In draw_timeseries_plot(%s)\n", main_title)

    flagged_point_color <- "gray"

    flagged <- data_frame[[flagged_column]]
    point_colors <- ifelse(flagged == "0", "black", flagged_point_color)
    has_flagged_points <-
      length(which(data_frame[[flagged_column]] != "0")) > 0L

    neighbor_point_colors <- NULL

    if (!is.null(neighbor_data_frame)) {
      neighbor_flagged <- neighbor_data_frame[[neighbor_flagged_column]]
      neighbor_point_colors <-
        ifelse(flagged == "0", "black", flagged_point_color)
      has_flagged_points <- has_flagged_points ||
        (length(which(neighbor_data_frame[[neighbor_flagged_column]] != "0"))
         > 0L)
    }

    result <- NULL

    if (!is.null(file_name)) {

      # Don't output pdf of interactive plots.
      # Instead use built-in interactive plot feature 'Download plot as a png'.

      interactive <- FALSE
      ASNAT_dprint("In draw_timeseries_plot() calling pdf(%s)\n", file_name)
      pdf(file_name, width = the_pdf_width, height = the_pdf_height)
      plot_result <-
        make_timeseries_plot_helper(data_frame,
                                    timestamp_column, site_column,
                                    measure_column, flagged_column,
                                    timestamp_format,
                                    time_0, time_last, minimum, maximum,
                                    interactive, main_title, x_label, y_label,
                                    point_colors, has_flagged_points,
                                    make_basic_timeseries_plot, NULL)

      if (!is.null(neighbor_data_frame)) {
        plot_result <-
          make_timeseries_plot_helper(neighbor_data_frame,
                                      neighbor_timestamp_column,
                                      neighbor_site_column,
                                      neighbor_measure_column,
                                      neighbor_flagged_column,
                                      timestamp_format,
                                      time_0, time_last, minimum, maximum,
                                      interactive, main_title, x_label, y_label,
                                      neighbor_point_colors,
                                      has_flagged_points,
                                      make_basic_timeseries_plot, plot_result)
      }

      result <- plot_result
      dev.off()
    } else if (!interactive) {
      result <- renderPlot({
        plot_result <-
          make_timeseries_plot_helper(data_frame,
                                      timestamp_column, site_column,
                                      measure_column, flagged_column,
                                      timestamp_format,
                                      time_0, time_last, minimum, maximum,
                                      interactive, main_title, x_label, y_label,
                                      point_colors, has_flagged_points,
                                      make_basic_timeseries_plot, NULL)

        if (!is.null(neighbor_data_frame)) {
          plot_result <-
            make_timeseries_plot_helper(neighbor_data_frame,
                                        neighbor_timestamp_column,
                                        neighbor_site_column,
                                        neighbor_measure_column,
                                        neighbor_flagged_column,
                                        timestamp_format,
                                        time_0, time_last, minimum, maximum,
                                        interactive,
                                        main_title, x_label, y_label,
                                        neighbor_point_colors,
                                        has_flagged_points,
                                        make_basic_timeseries_plot, plot_result)
        }

        return(plot_result)
      })
    } else {
      result <- renderPlotly({
        plot_result <-
          make_timeseries_plot_helper(data_frame,
                                      timestamp_column, site_column,
                                      measure_column, flagged_column,
                                      timestamp_format,
                                      time_0, time_last, minimum, maximum,
                                      interactive, main_title, x_label, y_label,
                                      point_colors, has_flagged_points,
                                      make_interactive_timeseries_plot, NULL)

        if (!is.null(neighbor_data_frame)) {
          plot_result <-
            make_timeseries_plot_helper(neighbor_data_frame,
                                        neighbor_timestamp_column,
                                        neighbor_site_column,
                                        neighbor_measure_column,
                                        neighbor_flagged_column,
                                        timestamp_format,
                                        time_0, time_last, minimum, maximum,
                                        interactive,
                                        main_title, x_label, y_label,
                                        neighbor_point_colors,
                                        has_flagged_points,
                                        make_interactive_timeseries_plot,
                                        plot_result)
        }

        return(plot_result)
      })
    }


    return(result)
  }



  # Draw dataset time-series plot of selected dataset (possibly filtered ids)
  # or, if a single site_id is specified with neighbor ids then plot single site
  # and its neighbors:

  draw_dataset_timeseries_plot <-
  function(dataset_name, dataset_variable, filter_ids,
           neighbor_dataset_name, neighbor_dataset_variable, neighbor_ids,
           neighbor_distance, save_to_file) {

    ASNAT_dprint("In draw_dataset_timeseries_plot(%s %s)\n",
                 dataset_name, dataset_variable)

    interactive <- use_interactive_plots(model) && !save_to_file

    # Get the data frame subsetted by filter_ids and store unique site ids:

    the_dataset <- set_dataset_variable(dataset_name, dataset_variable)
    the_data_frame <- data_frame(the_dataset)
    subset_data_frame <- the_data_frame
    column_names <- colnames(the_data_frame)
    site_column <- ASNAT_site_column_index(column_names)
    is_single_site <- FALSE
    single_site_id <- 0L

    # Filter the data frame by filter_ids:

    if (!is.null(filter_ids)) {
      sites <- filter_ids
      sites <- sort.int(sites)
      sites <- unique(sites)
      matched_rows <- which(the_data_frame[[site_column]] %in% sites)
      stopifnot(length(matched_rows) > 0L)
      is_single_site <- length(sites) == 1L

      if (is_single_site) {
        single_site_id <- sites[[1L]]
      }

      subset_data_frame <- the_data_frame[matched_rows, ]
    }

    if (nrow(subset_data_frame) < 1L) return(NULL)

    # Filter the neighbor data frame by neighbor_ids:

    neighbor_dataset <- NULL
    neighbor_data_frame <- NULL
    subset_neighbor_data_frame <- NULL
    neighbor_column_names <- NULL
    neighbor_site_column <- -1L

    if (is_single_site &&
        !is.null(neighbor_dataset_name) &&
        !is.null(neighbor_dataset_variable) &&
        !is.null(neighbor_ids)) {
      neighbor_dataset <-
        set_dataset_variable(neighbor_dataset_name, neighbor_dataset_variable)
      neighbor_data_frame <- data_frame(neighbor_dataset)
      neighbor_column_names <- colnames(neighbor_data_frame)
      neighbor_site_column <- ASNAT_site_column_index(neighbor_column_names)
      sites <- neighbor_ids
      sites <- sort.int(sites)
      sites <- unique(sites)
      matched_rows <-
        which(neighbor_data_frame[[neighbor_site_column]] %in% sites)
      stopifnot(length(matched_rows) > 0L)
      subset_neighbor_data_frame <- neighbor_data_frame[matched_rows, ]
    }

    # Create main title with date range, bbox, etc.
    # and y-axis label with measure and units
    # and x-axis with timestamps:

    units <- variable_units(the_dataset)
    source <- coverage_source(the_dataset)
    source_variable <- source_variable(the_dataset)
    fancy_source_variable <- source_variable
    the_variable <- variable_name(the_dataset)
    fancy_variable <- the_variable

    if (interactive) {
      fancy_variable <- fancy_label(the_variable)
      units <- fancy_label(units)
      fancy_source_variable <-
        paste0(coverage_source(the_dataset), ".",
               fancy_label(variable_name(the_dataset)))
    }

    # Get date-time range:

    first_model_timestamp <- first_timestamp(model)
    last_model_timestamp <- last_timestamp(model)
    model_timestep_size <- timestep_size(model)
    date_range <- substr(first_model_timestamp, 1L, 10L)

    if (days(model) > 1L) {
      date_range <-
        paste0(date_range, " - ", substr(last_model_timestamp, 1L, 10L))
    }

    timestamp_length <- 13L
    timestamp_format <- "%Y-%m-%dT%H"

    if (model_timestep_size == "days") {
      timestamp_length <- 10L
      timestamp_format <- "%Y-%m-%d"
    }

    first_model_timestamp <- substr(first_model_timestamp, 1L, timestamp_length)
    last_model_timestamp <- substr(last_model_timestamp, 1L , timestamp_length)
    time_0 <- as.POSIXct(first_model_timestamp, timestamp_format, tz = "UTC")
    time_last <- as.POSIXct(last_model_timestamp, timestamp_format, tz = "UTC")

    # Get bounds of viewing area:

    west <- west_bound(the_dataset)
    east <- east_bound(the_dataset)
    south <- south_bound(the_dataset)
    north <- north_bound(the_dataset)

    main_title <-
      sprintf("Dataset Time-series: %s\n%s (%0.4f, %0.4f) - (%0.4f, %0.4f)",
              ifelse(interactive, fancy_source_variable, source_variable),
              date_range, west, east, south, north)

    y_label <-
      paste0(ifelse(interactive, fancy_variable, the_variable),
             "(", units, ")")

    x_label <-
      paste0(if (model_timestep_size == "hours") "Hours" else "Days",
             " from ", first_model_timestamp, " to ", last_model_timestamp)

    # If plotting a single site with its neighbors then recreate main title:

    if (is_single_site &&
        !is.null(neighbor_dataset_name) &&
        !is.null(neighbor_dataset_variable) &&
        !is.null(neighbor_ids)) {
      longitudes <- subset_data_frame[[2L]]
      latitudes <- subset_data_frame[[3L]]
      longitude <- longitudes[[1L]]
      latitude <- latitudes[[1L]]
      neighbor_source_variable <- source_variable(neighbor_dataset)
      neighbor_variable <- variable_name(neighbor_dataset)
      fancy_neighbor_source_variable <- neighbor_source_variable

      if (interactive) {
        fancy_neighbor_source_variable <-
          paste0(coverage_source(neighbor_dataset), ".",
                 fancy_label(neighbor_variable))
      }

      main_title <-
        sprintf("%s Site %d Neighbors (<= %dm) Time-Series:\n%s vs %s\n%s (%0.4f, %0.4f)",
                source, single_site_id, neighbor_distance,
                ifelse(interactive, fancy_source_variable, source_variable),
                ifelse(interactive, fancy_neighbor_source_variable, neighbor_source_variable),
                date_range, longitude, latitude)
    }

    ASNAT_dprint("Rendering timeseriesplot with %s\n", source_variable)

    pdf_file <- NULL

    if (save_to_file) {
      directory <- output_directory(model)
      site_string <- ""

      if (is_single_site) {
        site_string <-
          paste0("_site_", single_site_id, "_neighbors_",
                 neighbor_source_variable)
      }

      pdf_file <-
        paste0(directory, "/",
               gsub(fixed = TRUE, ".", "_", source_variable),
               site_string,
               "_timeseries.pdf")
      saved_plot_files <<- append(saved_plot_files, pdf_file)
    }

    measure_column <- variable_column(the_dataset)
    measures <- subset_data_frame[[measure_column]]
    minimum <- min(measures)
    maximum <- max(measures)
    flagged_column <- ASNAT_flagged_column_index(column_names)

    # Compute neighbor column indices and update min/max:

    neighbor_measure_column <- -1L
    neighbor_flagged_column <- -1L

    if (!is.null(subset_neighbor_data_frame)) {
      neighbor_measure_column <- variable_column(neighbor_dataset)
      neighbor_flagged_column <-
        ASNAT_flagged_column_index(neighbor_column_names)
      neighbor_measures <- subset_neighbor_data_frame[[neighbor_measure_column]]
      neighbor_minimum <- min(neighbor_measures)
      neighbor_maximum <- max(neighbor_measures)
      minimum <- min(minimum, neighbor_minimum)
      maximum <- max(maximum, neighbor_maximum)
    }

    timestamp_column <- 1L

    result <-
      draw_timeseries_plot(subset_data_frame,
                           timestamp_column, site_column, measure_column,
                           flagged_column,
                           subset_neighbor_data_frame,
                           timestamp_column, neighbor_site_column,
                           neighbor_measure_column,
                           neighbor_flagged_column,
                           timestamp_format, time_0, time_last,
                           minimum, maximum,
                           interactive, main_title, x_label, y_label, pdf_file)
    return(result)
  }



  ########################### Scatterplot functions ##########################


  # Helper to make stats label for scatter plot:

  compute_scatterplot_stats <- function(x_values, y_values, interactive) {

    minimum_x <- min(x_values)
    maximum_x <- max(x_values)
    minimum_y <- min(y_values)
    maximum_y <- max(y_values)
    n <- length(x_values)
    correlation <- if (n > 1L) cor(x_values, y_values) else 0.0
    r_squared <- correlation * correlation
    err <- x_values - y_values
    se <- err * err
    mse <- mean(se)
    rmse <- sqrt(mse)

    mean_x_values <- mean(x_values)
    abs_x_values <- abs(x_values)

    nrmse <- rmse / mean_x_values * 100.0
    nmbe <- mean(err / abs_x_values) * 100.0

    slope <- cov(x_values, y_values) / var(x_values)
    y_intercept <- mean(y_values) - mean(x_values) * slope
    label <-
      sprintf(paste0("N: %d\n",
                     "Slope: %0.2f\n",
                     "Y-Intercept: %0.2f\n",
                     "R2: %0.2f\n",
                     "RMSE: %0.2f\n",
                     "NRMSE: %0.2f%%\n",
                     "NMBE: %0.2f%%"),
             n, slope, y_intercept, r_squared, rmse, nrmse, nmbe)

    # FIX: Replace R2 in stats_label with R-superscript-2:
    # https://www.statology.org/superscript-subscript-in-r/
    # https://coderclub.w.uib.no/2015/05/07/expressions-in-r/

    FANCY_LABEL_HACK <- FALSE

    if (FANCY_LABEL_HACK) {
      stats_label_before_R2 <-
        sprintf(paste0("N: %d\n",
                       "Slope: %0.2f\n",
                       "Y-Intercept: %0.2f\n"),
                n, slope, y_intercept)
      stats_label_after_R2 <-
        sprintf(paste0(": %0.2f\n",
                       "RMSE: %0.2f\n",
                       "NRMSE: %0.2f%%\n",
                       "NMBE: %0.2f%%"),
                r_squared, rmse, nrmse, nmbe)

      if (!interactive) {
        label <- paste0(label, "\n_____ is regression line")
      }

      label <-
        bquote(.(stats_label_before_R2)~R^2~.(stats_label_after_R2))
    }

    result <- list(label = label,
                   n = n, slope = slope, y_intercept = y_intercept,
                   r_squared = r_squared, rmse = rmse, nrmse = nrmse,
                   nmbe = nmbe)
    return(result)
  }



  # Helper to draw basic scatter plot:
  # https://r-coder.com/scatter-plot-r/
  # https://r-charts.com/base-r/title/

  make_basic_scatterplot <-
  function(x_values, y_values, main_title, x_label, y_label,
           has_flagged_points, point_colors) {

    x_minimum <- min(x_values)
    x_maximum <- max(x_values)
    y_minimum <- min(y_values)
    y_maximum <- max(y_values)
    y_range <- y_maximum - y_minimum
    text_line_height <- y_range * 0.05
    stats_label_x <- x_minimum
    stats_label_y <- y_minimum + y_range * 0.6
    yx_line_label_x <- stats_label_x
    yx_line_label_y <- stats_label_y - text_line_height
    yx_line_label <- "_____ is line y = x"
    stats <- compute_scatterplot_stats(x_values, y_values, FALSE)
    stats_label <- stats$label
    slope <- stats$slope
    y_intercept <- stats$y_intercept

    plot(x = x_values, y = y_values,
         xlim = c(x_minimum, x_maximum),
         ylim = c(y_minimum, y_maximum),
         main = main_title, xlab = x_label, ylab = y_label, las = 1L,
         col = point_colors)
    abline(a = 0.0, b = 1.0, col = "lightgray")
    abline(a = y_intercept, b = slope)
    text(stats_label, x = stats_label_x, y = stats_label_y, adj = c(0, 0))
    text(labels = yx_line_label,
         x = yx_line_label_x, y = yx_line_label_y, adj = c(0, 0),
         col = "lightgray")

    if (has_flagged_points) {
      flagged_label <- "o = flagged"
      flagged_point_color <- "gray"
      flagged_label_x <- stats_label_x
      flagged_label_y <- yx_line_label_y - text_line_height
      text(labels = flagged_label,
           x = flagged_label_x, y = flagged_label_y, adj = c(0, 0),
           col = flagged_point_color)
    }
  }



  # Helper to draw interactive scatter plot:

  make_interactive_scatterplot <-
  function(x_values, y_values, main_title, x_label, y_label,
           has_flagged_points, point_colors) {

    x_minimum <- min(x_values)
    x_maximum <- max(x_values)
    y_minimum <- min(y_values)
    y_maximum <- max(y_values)
    x_range <- x_maximum - x_minimum
    y_range <- y_maximum - y_minimum
    text_line_height <- y_range * 0.05
    stats_label_x <- x_minimum + x_range * 0.12
    stats_label_y <- y_minimum + y_range * 0.6
    stats <- compute_scatterplot_stats(x_values, y_values, TRUE)
    stats_label <- stats$label
    slope <- stats$slope
    y_intercept <- stats$y_intercept

    result <-
      plotly::plot_ly(x = x_values, y = y_values,
                      type = "scatter", mode = "markers",
                      # FIX: make markers hollow instead of solid.
                      symbols = "o",
                      marker = list(size = 4L,
                                    symbols = "circle-open",
                                    color = point_colors),
                      name = "Neighbor pair measurements") %>%
      # FIX: main title (3 lines) needs to be moved up.
      plotly::layout(title = main_title,
                     xaxis = list(title = x_label),
                     yaxis = list(title = y_label)) %>%
      plotly::add_trace(x = c(x_minimum, x_maximum),
                        y = c(y_minimum, y_maximum),
                        type = "scatter", mode = "lines",
                        line = list(color = "lightgray",
                                    dash = "dotted",
                                    width = 1L),
                        name = "line y = x") %>%
      plotly::add_trace(x = c(x_minimum, x_maximum),
                        y = c(slope * x_minimum + y_intercept,
                              slope * x_maximum + y_intercept),
                        type = "scatter", mode = "lines",
                        line = list(color = "black",
                                    dash = "dashed",
                                    width = 1L),
                        name = "regression line") %>%
      plotly::layout(annotations = list(text = stats_label,
                                        textposition = "top left",
                                        align = "left",
                                        x = stats_label_x,
                                        y = stats_label_y))

    if (has_flagged_points) {
      flagged_label <- "o = flagged"
      flagged_point_color <- "gray"

      result <- result %>%
        plotly::layout(annotations = list(showarrow = FALSE,
                                          text = flagged_label,
                                          textposition = "top left",
                                          x = stats_label_x,
                                          y = y_maximum,
                                          color = flagged_point_color))
    }

    return(result)
  }



  # Draw scatter plot of selected X/Y datasets:
  # https://r-coder.com/scatter-plot-r/
  # https://r-charts.com/base-r/title/

  draw_scatterplot <- function(dataset_name_x, dataset_x_variable,
                               dataset_name_y, dataset_y_variable,
                               single_site,
                               only_unflagged,
                               save_to_file) {

    ASNAT_dprint("In draw_scatterplot(%s (%s), %s (%s))\n",
                 dataset_name_x, dataset_x_variable,
                 dataset_name_y, dataset_y_variable)

    result <- NULL
    data_frame <- comparison_data_frame(model)

    # data_frame columns are:
    # 1 = timestamp, 2 = id_x, 3 = measure_x, 4 = id_y, 5 = measure_y, 6 = flagged_y

    if (nrow(data_frame) > 0L) {

      # If a single dataset_x site is specified then subset to only the
      # rows of that site.

      if (single_site > 0L) {
        matched_rows <- which(data_frame[[2L]] == single_site)
        stopifnot(length(matched_rows) > 0L)
        data_frame <- data_frame[matched_rows, ]
      }

      unflagged_rows <- which(data_frame[[6L]] == "0")

      if (only_unflagged == FALSE || length(unflagged_rows) > 0L) {
        dataset_x <- set_dataset_variable(dataset_name_x, dataset_x_variable)
        dataset_y <- set_dataset_variable(dataset_name_y, dataset_y_variable)
        source_variable_x <- source_variable(dataset_x)
        source_variable_y <- source_variable(dataset_y)
        source <- coverage_source(dataset_x)
        subtitle <- comparison_subtitle(model)
        main_title <- comparison_title(model)
        main_title <- gsub(fixed = TRUE, ": ", ":\nx = ", main_title)
        main_title <- gsub(fixed = TRUE, " vs ", " y = ", main_title)

        if (single_site > 0L) {
          main_title <- paste0(source, " Site ", single_site, " ", main_title)

          # Change subtitle lon-lat bounds to single site location:

          dataset_x <- find_dataset(model, dataset_name_x)
          data_frame_x <- data_frame(dataset_x)
          column_names <- colnames(data_frame_x)
          site_column <- ASNAT_site_column_index(column_names)
          site_rows <- which(data_frame_x[[site_column]] == single_site)
          first_site_row <- site_rows[[1L]]
          longitude <- data_frame_x[first_site_row, 2L]
          latitude <- data_frame_x[first_site_row, 3L]
          date_range <- unlist(strsplit(subtitle, "(", fixed = TRUE))[1L]
          subtitle <-
            sprintf("%s (%0.5f, %0.5f)", date_range, longitude, latitude)
        }

        main_title <- paste0(main_title, "\n", subtitle)

        x_y_column_names <- colnames(data_frame)
        x_label <- x_y_column_names[[3L]]
        y_label <- x_y_column_names[[5L]]

        using_fancy_plots <- !save_to_file && use_interactive_plots(model)

        measures_x <- data_frame[[3L]]
        measures_y <- data_frame[[5L]]
        point_colors <- NULL
        has_flagged_points <- FALSE

        if (only_unflagged) {
          main_title <- paste0("Unflagged ", main_title)
          measures_x <- measures_x[unflagged_rows]
          measures_y <- measures_y[unflagged_rows]
          point_colors <- rep("black", length(measures_x))
        } else {
          point_colors <-
            ifelse(data_frame[[6L]] == "0", "black", flagged_point_color)
          has_flagged_points <- length(which(data_frame[[6L]] != "0")) > 0L
        }

        ASNAT_dprint("measures_x:\n")
        ASNAT_debug(str, measures_x)
        ASNAT_dprint("measures_y:\n")
        ASNAT_debug(str, measures_y)
        ASNAT_dprint("Rendering scatterplot\n")
        result <- NULL

        if (save_to_file) {
          directory <- output_directory(model)
          first_part <- gsub(fixed = TRUE, ".", "_", source_variable_x)

          if (single_site > 0L) {
            first_part <-
              paste0(first_part, "_site_", single_site, "_neighbors")
          }

          file_name <-
            paste0(directory, "/",
                   first_part,
                   "_vs_",
                   gsub(fixed = TRUE, ".", "_", source_variable_y),
                   "_scatterplot",
                   if (only_unflagged) "_unflagged.pdf" else ".pdf")
          saved_plot_files <<- append(saved_plot_files, file_name)
          ASNAT_dprint("In draw_scatterplot() calling pdf(%s)\n", file_name)
          pdf(file_name, width = the_pdf_width, height = the_pdf_height)
          make_basic_scatterplot(measures_x, measures_y,
                                 main_title, x_label, y_label,
                                 has_flagged_points, point_colors)
          dev.off()
        } else {

          if (!using_fancy_plots) {
            result <- renderPlot({
              make_basic_scatterplot(measures_x, measures_y,
                                     main_title, x_label, y_label,
                                     has_flagged_points, point_colors)
            })
          } else {
            fancy_main_title <- fancy_label(main_title)
            fancy_x_label <- fancy_label(x_label)
            fancy_y_label <- fancy_label(y_label)

            result <- renderPlotly({
              make_interactive_scatterplot(measures_x, measures_y,
                                           fancy_main_title,
                                           fancy_x_label, fancy_y_label,
                                           has_flagged_points, point_colors)
            })
          }
        }
      }
    }

    return(result)
  }



  plotting <- FALSE

  # Helper function to draw all of the plots:

  draw_plots <- function(save_to_file) {
    ASNAT_dprint("draw_plots(%d) called.\n", as.integer(save_to_file))
    timer <- ASNAT_start_timer()

    ASNAT_dprint("plotting = %d\n", as.integer(plotting))

    have <- have_datasets()
    have_x <- have$x
    have_y <- have$y

    if (plotting || !have_x) {
      return(NULL)
    }

    plotting <<- TRUE
    ASNAT_dprint("  set plotting = %d\n", as.integer(plotting))
    showNotification("Plotting data...",
                     duration = NULL, closeButton = FALSE,
                     id = "message_popup", type = "message")

    using_interactive_plots <- use_interactive_plots(model)

    if (using_interactive_plots) {
      shinyjs::hide(id = "boxplot_x")
      shinyjs::show(id = "interactive_boxplot_x")
      shinyjs::hide(id = "timeseriesplot_x")
      shinyjs::show(id = "interactive_timeseriesplot_x")
      shinyjs::hide(id = "boxplot_y")
      shinyjs::show(id = "interactive_boxplot_y")
      shinyjs::hide(id = "timeseriesplot_y")
      shinyjs::show(id = "interactive_timeseriesplot_y")
      shinyjs::hide(id = "scatterplot_xy")
      shinyjs::show(id = "interactive_scatterplot_xy")
      shinyjs::hide(id = "scatterplot_xy_unflagged")
      shinyjs::show(id = "interactive_scatterplot_xy_unflagged")
    } else {
      shinyjs::show(id = "boxplot_x")
      shinyjs::hide(id = "interactive_boxplot_x")
      shinyjs::show(id = "timeseriesplot_x")
      shinyjs::hide(id = "interactive_timeseriesplot_x")
      shinyjs::show(id = "boxplot_y")
      shinyjs::hide(id = "interactive_boxplot_y")
      shinyjs::show(id = "timeseriesplot_y")
      shinyjs::hide(id = "interactive_timeseriesplot_y")
      shinyjs::show(id = "scatterplot_xy")
      shinyjs::hide(id = "interactive_scatterplot_xy")
      shinyjs::show(id = "scatterplot_xy_unflagged")
      shinyjs::hide(id = "interactive_scatterplot_xy_unflagged")
    }

    the_maximum_neighbor_distance <- maximum_neighbor_distance(model)
    model_summary_x_data_frame_ids <- NULL
    model_summary_y_data_frame_ids <- NULL
    model_summary_x_data_frame <- summary_x_data_frame(model)
    model_summary_y_data_frame <- summary_y_data_frame(model)
    selected_dataset_x_site <- 0L

    if (!is.null(model_summary_x_data_frame)) {

      if (have_y && nchar(input$neighbors_menu[1L]) > 0L) {
        selected_dataset_x_site <-
          as.integer(unlist(strsplit(input$neighbors_menu[1L], " "))[1L])
      }

      if (selected_dataset_x_site > 0L) {
        model_summary_x_data_frame_ids <- selected_dataset_x_site
        model_comparison_data_frame <- comparison_data_frame(model)

        if (!is.null(model_comparison_data_frame) &&
            !is.null(model_summary_y_data_frame) &&
            ASNAT_units_match(input$dataset_x_variable_menu[1L],
                              input$dataset_y_variable_menu[1L])) {
          matched_rows <-
            which(model_comparison_data_frame[[2L]] == selected_dataset_x_site)
          subset_data_frame <- model_comparison_data_frame[matched_rows, ]
          model_summary_y_data_frame_ids <- subset_data_frame[[4L]]
        }
      } else {
        model_summary_x_data_frame_ids <- model_summary_x_data_frame[[1L]]
      }
    }

    # BUG: When selecting a single Dataset X Site and then clicking make_plots
    # button sometimes only the Timeseries plot appears. Clicking make_plots
    # again makes all plots appear.

    draw_result1 <-
      draw_dataset_boxplot(input$dataset_x_menu[1L],
                           input$dataset_x_variable_menu[1L],
                           model_summary_x_data_frame_ids,
                           input$dataset_y_menu[1L],
                           input$dataset_y_variable_menu[1L],
                           model_summary_y_data_frame_ids,
                           the_maximum_neighbor_distance,
                           save_to_file)

    draw_result2 <-
      draw_dataset_timeseries_plot(input$dataset_x_menu[1L],
                                   input$dataset_x_variable_menu[1L],
                                   model_summary_x_data_frame_ids,
                                   input$dataset_y_menu[1L],
                                   input$dataset_y_variable_menu[1L],
                                   model_summary_y_data_frame_ids,
                                   the_maximum_neighbor_distance,
                                   save_to_file)

    if (!save_to_file) {

      if (!using_interactive_plots) {
        output$boxplot_x <- draw_result1
        output$timeseriesplot_x <- draw_result2
      } else {
        output$interactive_boxplot_x <- draw_result1
        output$interactive_timeseriesplot_x <- draw_result2
      }
    }

    draw_result3 <- renderPlot({NULL})
    draw_result4 <- renderPlot({NULL})
    draw_result5 <- renderPlot({NULL})
    draw_result6 <- renderPlot({NULL})

    if (have_y) {

      # If a single Dataset X site is selected then
      # do not plot Dataset Y boxplot or Dataset Y timeseries plot.
      # Instead, the Dataset Y neighbors are included in the Dataset X boxplot
      # and Dataset X timeseries plot.

      if (selected_dataset_x_site > 0L) {
        shinyjs::hide(id = "boxplot_y")
        shinyjs::hide(id = "interactive_boxplot_y")
        shinyjs::hide(id = "timeseriesplot_y")
        shinyjs::hide(id = "interactive_timeseriesplot_y")
      } else {

        if (!is.null(model_summary_y_data_frame)) {
          model_summary_y_data_frame_ids <- model_summary_y_data_frame[[1L]]
        }

        draw_result3 <-
          draw_dataset_boxplot(input$dataset_y_menu[1L],
                               input$dataset_y_variable_menu[1L],
                               model_summary_y_data_frame_ids,
                               NULL, NULL, NULL, 0.0,
                               save_to_file)

        draw_result4 <-
          draw_dataset_timeseries_plot(input$dataset_y_menu[1L],
                                       input$dataset_y_variable_menu[1L],
                                       model_summary_y_data_frame_ids,
                                       NULL, NULL, NULL, 0.0,
                                       save_to_file)
      }

      # If there is a Dataset Y then draw the scatter plots -
      # either for all pairs of neighboring points or
      # (if selected_data_x_site > 0) for only those Y neigbors of the single
      # selected_data_x_site.

      draw_result5 <-
        draw_scatterplot(input$dataset_x_menu[1L],
                         input$dataset_x_variable_menu[1L],
                         input$dataset_y_menu[1L],
                         input$dataset_y_variable_menu[1L],
                         selected_dataset_x_site,
                         FALSE,
                         save_to_file)

      draw_result6 <-
        draw_scatterplot(input$dataset_x_menu[1L],
                         input$dataset_x_variable_menu[1L],
                         input$dataset_y_menu[1L],
                         input$dataset_y_variable_menu[1L],
                         selected_dataset_x_site,
                         TRUE,
                         save_to_file)
    }

    if (!save_to_file) {

      if (!using_interactive_plots) {
        output$boxplot_y <- draw_result3
        output$timeseriesplot_y <- draw_result4
        output$scatterplot_xy <- draw_result5
        output$scatterplot_xy_unflagged <- draw_result6
      } else {
        output$interactive_boxplot_y <- draw_result3
        output$interactive_timeseriesplot_y <- draw_result4
        output$interactive_scatterplot_xy <- draw_result5
        output$interactive_scatterplot_xy_unflagged <- draw_result6
      }
    }

    removeNotification("message_popup")
    plotting <<- FALSE
    ASNAT_dprint("  reset plotting = %d\n", as.integer(plotting))
    ASNAT_elapsed_timer("draw_plots:", timer)
  }



  # Callback for make_plots button:

  observeEvent(input$make_plots, {

    # Ensure that summary and comparison data is available:

    the_summary_x_data_frame <- summary_x_data_frame(model)
    the_summary_y_data_frame <- summary_y_data_frame(model)

    recompute <-
      nrow(the_summary_x_data_frame) == 0L ||
      (input$dataset_y_menu[[1L]] != "none" &&
       nrow(the_summary_y_data_frame) == 0L) ||
      (input$dataset_y_menu[[1L]] == "none" &&
       nrow(the_summary_y_data_frame) > 0L)

    if (recompute) {
      summarize_and_compare_datasets_x_y()
    }

    draw_plots(FALSE)
  })



 # Get selected Dataset X site number (or 0):

  get_selected_dataset_x_site <- function() {
    result <- 0L

    is_valid_input <-
      shiny::isTruthy(input$neighbors_menu) &&
      !is.na(input$neighbors_menu) &&
      nchar(input$neighbors_menu) > 0L

    if (is_valid_input) {
      selection <- input$neighbors_menu
      parts <- unlist(strsplit(selection, " "))
      result <- as.integer(parts[[1L]])
    }

    return(result)
  }



  # Save all plots as pdf files and site neighbor map as a png file.
  # Returns a vector of names of saved files.

  save_plot_files <- function() {
    ASNAT_dprint("In save_plot_files()\n")
    timer <- ASNAT_start_timer()

    saved_plot_files <<- vector()

    if (dataset_count(model) > 0L) {
      check_set_reset_output_directory()
      ASNAT_dprint("save_plot_files() calling draw_plots(TRUE)\n")
      draw_plots(TRUE)
      ASNAT_dprint("done\n")

      # Also save site_neighbor_map if plotting site neighbors:

      selected_site <- get_selected_dataset_x_site()
      save_map_file <- TRUE # !ASNAT_is_remote_hosted

      if (selected_site > 0L && save_map_file) {
        map_file_name <-
          paste0(output_directory(model),
                 sprintf("/map_image_site_%d.png", selected_site))
        map_file_name <-
          create_map_image_file(the_site_neighbor_map,
                                the_site_neighbor_map_width,
                                the_site_neighbor_map_height,
                                map_file_name)

        if (file.exists(map_file_name)) {
          saved_plot_files <<- append(saved_plot_files, map_file_name)
        }
      }

      output$message_area <- renderPrint({cat(saved_plot_files, sep = "\n")})
    }

    ASNAT_elapsed_timer("save_plot_files:", timer)
    ASNAT_dprint("save_plot_files() returning\n");
    return(saved_plot_files)
  }



  # Callback for Save Plots button - when not remote-hosted:

  observeEvent(input$save_plots, {
    save_plot_files()
  })



  # Callback for Download Plots button - when remote-hosted:

  output$download_plots <- downloadHandler(
    filename = "ASNAT_plots.zip",
    content = function(file) {
      #cat("In download_plots downloadHandler() content function\n")
      file_names <- save_plot_files()
      #cat("In downloadHandler content function, file_names:"); str(file_names)

      if (length(file_names) > 0L) {
        # cat(sep = "", "file_names[[1L]] = '", file_names[[1L]], "' exists = ",
        #    file.exists(file_names[[1L]]), "\n")
        #utils::zip(file, files = file_names, flags = "-j")
        zip::zip(file, files = file_names,
                 recurse = FALSE, include_directories = FALSE,
                 mode = "cherry-pick")
      }
    },
    contentType = "application/zip"
  )

}



###############################################################################
# Run the app:
###############################################################################
shinyApp(ui, server)

